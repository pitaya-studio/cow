﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Configuration;
using System.Data.Sql;
using System.Data;
using Lib.DBUtility;
namespace Lib.BLL
{
    public class X6Methods
    {
        #region 获取用户权限下的场区列表，并返回 场区数量，ID，名称。
        /// <summary>
        /// 获取用户权限下的场区列表，并返回 场区数量，ID，名称。
        /// 如果只有一个场区的话，则返回场区ID和场区名称。
        /// </summary>
        /// <param name="userName">登录名</param>
        /// <param name="farmCount">返回的场区数量</param>
        /// <param name="farmId">返回的场区ID</param>
        /// <param name="farmName">返回的场区名称</param>
        /// <returns></returns>
        public static string GetUserFarmsByUserName(string userName, out int farmCount, out int farmId, out string farmName)
        {
            string json_farms = string.Empty;
            SqlDataReader reader = GetUserFarmsByUserName(userName);
            farmCount = 0;
            farmId = 0;
            farmName = string.Empty;

            while (reader.Read())
            {
                farmCount++;
                string Farm_Id = reader["Farm_Id"].ToString();
                string Farm_Name = reader["Farm_Name"].ToString();


                if (farmCount == 1)
                {
                    farmId = int.Parse(Farm_Id);
                    farmName = Farm_Name;
                }
                if (json_farms == string.Empty)
                {
                    json_farms = "{\"Farm_Id\":\"" + Farm_Id + "\",\"Farm_Name\":\"" + Farm_Name + "\"}";
                }
                else
                {
                    json_farms += ",{\"Farm_Id\":\"" + Farm_Id + "\",\"Farm_Name\":\"" + Farm_Name + "\"}";
                }
            }
            reader.Close();
            return json_farms;
        }
        #endregion

        #region 对 Core 进行操作
        /// <summary>
        /// 返回该用户有多少场区权限
        /// </summary>
        public static SqlDataReader GetUserFarmsByUserName(string userName)
        {
            string sql = @"select b.Farm_Id,b.Farm_Name from Sys_User u,Bird_FarmBasicInfo b,Sys_RolesAuthData s
where u.User_Name='{0}' and s.DataNode_TypeID=6 and s.Auth_Value='Browse=1'
and u.Roles_Id=s.Roles_Id and b.Farm_Id=cast(s.DataNode_Id as int)";
            sql = string.Format(sql, userName);
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            return reader;
        }
        #endregion

        #region 验证用户名密码
        /// <summary>
        /// 验证用户名密码
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="User_Pwd"></param>
        /// <returns></returns>
        public static string IsAuthenticated(string UserName, string User_Pwd)
        {
            UserName = UserName.Replace("'", "''").Replace("--", "").Replace("/*", "").Replace("*/", "").Replace("*", "");
            User_Pwd = User_Pwd.Replace("'", "''").Replace("--", "").Replace("/*", "").Replace("*/", "").Replace("*", "");
            if (ConfigurationManager.AppSettings["IsEncryption"] == "1")
            {
                User_Pwd = Encrypt3DES(User_Pwd, "Ly2011", System.Text.Encoding.ASCII);
            }
            string User_TrueName = string.Empty;
            string sql = "SELECT User_TrueName FROM Sys_User WHERE (User_Name = N'" +
              UserName + "') AND (User_Pwd = N'" + User_Pwd + @"') AND WorkStatus=1;";

            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                User_TrueName = reader["User_TrueName"] == null ? "" : reader["User_TrueName"].ToString();
            }
            reader.Close();
            return User_TrueName;
        }
        #endregion

        #region 3des加密字符串  X6里边也是用的这个加密方法
        /// <summary>
        /// 3des加密字符串  X6里边也是用的这个加密方法
        /// </summary>
        /// <param name="a_strString">要加密的字符串</param>
        /// <param name="a_strKey">密钥</param>
        /// <param name="encoding">编码方式</param>
        /// <returns>加密后并经base63编码的字符串</returns>
        /// <remarks>重载，指定编码方式</remarks>
        public static string Encrypt3DES(string a_strString, string a_strKey, Encoding encoding)
        {
            TripleDESCryptoServiceProvider DES = new
                TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider hashMD5 = new MD5CryptoServiceProvider();

            DES.Key = hashMD5.ComputeHash(encoding.GetBytes(a_strKey));
            DES.Mode = CipherMode.ECB;

            ICryptoTransform DESEncrypt = DES.CreateEncryptor();

            byte[] Buffer = encoding.GetBytes(a_strString);
            return Convert.ToBase64String(DESEncrypt.TransformFinalBlock
                (Buffer, 0, Buffer.Length));
        }
        #endregion


        #region 获取某个场区的牛群概貌数据
        /// <summary>
        /// 获取某场区的牛群概貌数据 2012-02-21
        /// </summary>
        /// <returns></returns>
        public static string GetOneFarmData()
        {
            string JsonData = string.Empty;
            string Json_Details1 = string.Empty; //牛群概貌
            string Json_Details2 = string.Empty; //昨日事件汇总
            string Json_Details3 = string.Empty; //预警

            string sql = @"select (select count(*) from view_DairyBaseCow where IsOnFarm=1) as Total,
                        (select count(*) from view_DairyBaseCow where GrowStatus='泌乳牛' and IsOnFarm=1) as MilkCowCount,
                        (select count(*) from view_DairyBaseCow where GrowStatus='干奶牛' and IsOnFarm=1) as DryCowCount,
                        (select count(*) from view_DairyBaseCow where LactationNumber=0 and IsOnFarm=1 and GrowStatus!='留养公牛') as HeiferCount";
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                Json_Details1 = "{\"Name\":\"总头数\",\"Value\":\"" + reader[0].ToString() + "\"}";
                Json_Details1 += ",{\"Name\":\"泌乳牛\",\"Value\":\"" + reader[1].ToString() + "\"}";
                Json_Details1 += ",{\"Name\":\"干奶牛\",\"Value\":\"" + reader[2].ToString() + "\"}";
                Json_Details1 += ",{\"Name\":\"后备牛\",\"Value\":\"" + reader[3].ToString() + "\"}";
            }
            reader.Close();
            sql = @"select 
                    (
                    select COUNT(*) from View_EventsAll where convert(date,EventsDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as Total,
                    (
                    select COUNT(*) from View_EventsAll where Events_Code='LC' and convert(date,EventsDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as LC,
                    (
                    select COUNT(*) from View_EventsAll where Events_Code='LQ' and convert(date,EventsDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as LQ,
                    (
                    select COUNT(*) from View_EventsAll where Events_Code='CD' and convert(date,EventsDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as CD,
                    (
                    select COUNT(*) from View_EventsAll where Events_Code='FB' and convert(date,EventsDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as FB,
                    (
                    select COUNT(*) from DairyCow_Disease where RecoveryDate is not null and convert(date,RecoveryDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as KF,
                    (
                    select COUNT(*) from View_EventsAll where Events_Code='PZ' and convert(date,EventsDate)=CONVERT(date,DATEADD(DAY,-1,getdate()))
                    ) as PZ";
            reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                Json_Details2 = "{\"Name\":\"总数\",\"Value\":\"" + reader["Total"].ToString() + "\"}";
                Json_Details2 += ",{\"Name\":\"流产\",\"Value\":\"" + reader["LC"].ToString() + "\"}";
                Json_Details2 += ",{\"Name\":\"离群\",\"Value\":\"" + reader["LQ"].ToString() + "\"}";
                Json_Details2 += ",{\"Name\":\"产犊\",\"Value\":\"" + reader["CD"].ToString() + "\"}";
                Json_Details2 += ",{\"Name\":\"发病\",\"Value\":\"" + reader["FB"].ToString() + "\"}";
                Json_Details2 += ",{\"Name\":\"康复\",\"Value\":\"" + reader["KF"].ToString() + "\"}";
                Json_Details2 += ",{\"Name\":\"配种\",\"Value\":\"" + reader["PZ"].ToString() + "\"}";
            }
            reader.Close();
            sql = @"select
                    0 as FQN,
                    (
                    select count(Cow_Id) from view_DairyBaseCow b where AfterInsemDay>=40 and FertilityStatus='已配未检' 
                    and IsOnFarm=1
                    ) as CJTZ,
                    (
                    select count(Cow_Id) from view_DairyBaseCow b
                    where PregantDays>=220 and LactationNumber>0  
                    and GrowStatus='泌乳牛' 
                    and FertilityStatus in('初检+','复检+')
                    and IsOnFarm=1
                    ) as GNTZ,
                    (
                    select count(Cow_Id) from view_DairyBaseCow b
                    where BeforeCalvingDay<=10 and IsOnFarm=1 and FertilityStatus like '%+%'
                    ) as LCTZ";
            reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                Json_Details3 = "{\"Name\":\"发情牛\",\"Value\":\"" + reader["FQN"].ToString() + "\"}";
                Json_Details3 += ",{\"Name\":\"初检通知\",\"Value\":\"" + reader["CJTZ"].ToString() + "\"}";
                Json_Details3 += ",{\"Name\":\"干奶通知\",\"Value\":\"" + reader["GNTZ"].ToString() + "\"}";
                Json_Details3 += ",{\"Name\":\"临产通知\",\"Value\":\"" + reader["LCTZ"].ToString() + "\"}";
            }
            reader.Close();

            Json_Details1 = "\"Details1\":[" + Json_Details1 + "]";
            Json_Details2 = "\"Details2\":[" + Json_Details2 + "]";
            Json_Details3 = "\"Details3\":[" + Json_Details3 + "]";

            JsonData = Json_Details1 + "," + Json_Details2 + "," + Json_Details3;
            return JsonData;
        }
        #endregion

        #region 获取某一头牛的基本信息，事件列表，照片信息
        /// <summary>
        /// 获取某一头牛的基本信息，事件列表，照片信息 2012-02-21
        /// </summary>
        /// <param name="Farm_Id">场区ID</param>
        /// <returns></returns>
        public static string GetOneCowData(string EarNum)
        {
            string JsonData = string.Empty;
            string Json_BasicData = GetOneCowBasicData(EarNum); //基本资料
            string Json_EventData = GetOneCowEventData(EarNum); //事件信息
            string Json_PhotoData = GetOneCowPhotoData(EarNum); //照片路径
            JsonData = "{" + Json_BasicData + "," + Json_EventData + "," + Json_PhotoData + "}";
            return JsonData;
        }
        #endregion

        #region 获取某一头牛的基本信息
        /// <summary>
        /// 获取某一头牛的基本信息 2012-02-21
        /// </summary>
        /// <param name="EarNum">牛号</param>
        /// <returns></returns>
        public static string GetOneCowBasicData(string EarNum)
        {
            string Json_BasicData = string.Empty; //基本信息

            string sql = @"select Cow_Id,EarNum,LactationNumber,Group_Name,Pedometer,FertilityStatus,GrowStatus,Convert(DATE,BirthDate) as BirthDate,convert(decimal(18,2),MonthAge) as MonthAge,Convert(DATE,CalvingDate) as CalvingDate,MilkDay,CONVERT(DATE,InsemDate) as InsemDate,InscminationNumber,AfterAbortionDay,IsForbid,AfterInsemDay,CONVERT(DATE,PlanCalvingDate) as PlanCalvingDate,HealthStatus,CONVERT(DATE,PlanDryDate) as PlanDryDate,DiseaseName,CONVERT(DATE,ExitDate) as ExitDate,ExitReason,IsOnFarm from view_DairyBaseCow where EarNum='" + EarNum + "'";
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                Json_BasicData = "{\"Name\":\"牛ID\",\"Value\":\"" + reader["Cow_Id"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"牛号\",\"Value\":\"" + reader["EarNum"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"胎次\",\"Value\":\"" + reader["LactationNumber"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"组别\",\"Value\":\"" + reader["Group_Name"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"计步器\",\"Value\":\"" + reader["Pedometer"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"繁殖状态\",\"Value\":\"" + reader["FertilityStatus"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"牛只类别\",\"Value\":\"" + reader["GrowStatus"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"出生日期\",\"Value\":\"" + reader["BirthDate"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"月龄\",\"Value\":\"" + reader["MonthAge"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"产犊日期\",\"Value\":\"" + reader["CalvingDate"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"泌乳天数\",\"Value\":\"" + reader["MilkDay"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"配种日期\",\"Value\":\"" + reader["InsemDate"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"配次\",\"Value\":\"" + reader["InscminationNumber"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"流产后天数\",\"Value\":\"" + reader["AfterAbortionDay"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"是否禁配\",\"Value\":\"" + reader["IsForbid"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"配后天数\",\"Value\":\"" + reader["AfterInsemDay"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"预计产犊日期\",\"Value\":\"" + reader["PlanCalvingDate"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"健康状态\",\"Value\":\"" + reader["HealthStatus"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"预计停奶日期\",\"Value\":\"" + reader["PlanDryDate"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"上次发病\",\"Value\":\"" + reader["DiseaseName"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"离群日期\",\"Value\":\"" + reader["ExitDate"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"离群原因\",\"Value\":\"" + reader["ExitReason"].ToString() + "\"}";
                Json_BasicData += ",{\"Name\":\"是否在场\",\"Value\":\"" + reader["IsOnFarm"].ToString() + "\"}";
            }
            reader.Close();
            Json_BasicData = "\"BasicData\":[" + Json_BasicData + "]";

            return Json_BasicData;
        }
        #endregion

        #region 获取某一头牛的事件信息
        /// <summary>
        /// 获取某一头牛的事件信息 2012-02-21
        /// </summary>
        /// <param name="Farm_Id">场区ID</param>
        /// <returns></returns>
        public static string GetOneCowEventData(string EarNum)
        {
            string Json_EventData = string.Empty; //事件信息

            string sql = @"select Events_Name,CONVERT(DATE,EventsDate) as EventsDate,ISNULL(EventDescription,'') as EventDescription from View_EventsAll where Cow_Id=(select Cow_Id from Base_Cow where EarNum='{0}')
order by EventsDate desc";
            sql = string.Format(sql, EarNum);
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            while (reader.Read())
            {
                if (Json_EventData == string.Empty)
                {
                    Json_EventData = "{\"EventName\":\"" + reader["Events_Name"].ToString() + "\",\"EventDate\":\"" + reader["EventsDate"].ToString() + "\",\"EventDesc\":\"" + reader["EventDescription"].ToString() + "\"}";
                }
                else
                {
                    Json_EventData += ",{\"EventName\":\"" + reader["Events_Name"].ToString() + "\",\"EventDate\":\"" + reader["EventsDate"].ToString() + "\",\"EventDesc\":\"" + reader["EventDescription"].ToString() + "\"}";
                }
            }
            reader.Close();
            Json_EventData = "\"EventData\":[" + Json_EventData + "]";

            return Json_EventData;
        }
        #endregion

        #region 获取某一头牛的照片信息
        /// <summary>
        /// 获取某一头牛的照片信息 2012-02-21
        /// </summary>
        /// <param name="Farm_Id">场区ID</param>
        /// <returns></returns>
        public static string GetOneCowPhotoData(string EarNum)
        {
            string Json_PhotoData = string.Empty; //照片信息
            string ImagesDomain = ConfigurationManager.AppSettings["ImagesDomain"];

            string sql = @"select convert(decimal(18,2),MonthAge) as MonthAge,
case when TakePhotoDate is null then CONVERT(DATE,CreateDate) else CONVERT(DATE,TakePhotoDate) end as TakePhotoDate,
 (select User_TrueName from sys_user where User_Name=DairyCow_UnitImage.Creator) as PhotoMarker ,ImageUrl from DairyCow_UnitImage where Cow_Id=(select Cow_Id from Base_Cow where EarNum='{0}')
order by CreateDate desc";
            sql = string.Format(sql, EarNum);
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            while (reader.Read())
            {
                string PhotoMaker = reader["PhotoMarker"] == null ? string.Empty : reader["PhotoMarker"].ToString();
                string ImageUrl = reader["ImageUrl"] == null ? string.Empty : reader["ImageUrl"].ToString();
                ImageUrl = ImagesDomain + ImageUrl;

                if (Json_PhotoData == string.Empty)
                {
                    Json_PhotoData = "{\"MonthAge\":\"" + reader["MonthAge"].ToString() + "\",\"TakePhotoDate\":\"" + reader["TakePhotoDate"].ToString() + "\",\"PhotoMarker\":\"" + PhotoMaker + "\",\"PhotoUrl\":\"" + ImageUrl + "\"}";
                }
                else
                {
                    Json_PhotoData += ",{\"MonthAge\":\"" + reader["MonthAge"].ToString() + "\",\"TakePhotoDate\":\"" + reader["TakePhotoDate"].ToString() + "\",\"PhotoMarker\":\"" + PhotoMaker + "\",\"PhotoUrl\":\"" + ImageUrl + "\"}";
                }
            }
            reader.Close();
            Json_PhotoData = "\"PhotoData\":[" + Json_PhotoData + "]";

            return Json_PhotoData;
        }
        #endregion

        #region 牛群概貌 生成当前在群牛统计数据

        #region 牛群概貌 生成当前在群牛统计数据 Json
        /// <summary>
        /// 牛群概貌 生成当前在群牛统计数据 Json
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static string GetOneFarmStatusData(string Farm_Id)
        {
            string Json_FarmStatusData = string.Empty;
            string Json_MilkCowData = GetMilkCowData(Farm_Id);
            string Json_DryCowData = GetDryCowData(Farm_Id);
            string Json_HeiferCowData = GetHeiferData(Farm_Id);
            string Json_CowData = GetCowData(Farm_Id);
            string Json_AnotherHeiferData = GetAnotherHeiferData(Farm_Id);

            Json_FarmStatusData = "{" + Json_MilkCowData + "," + Json_DryCowData + "," + Json_HeiferCowData + "," + Json_CowData + "," + Json_AnotherHeiferData + "}";

            return Json_FarmStatusData;
        }

        #endregion

        #region 获取泌乳牛报表数据
        /// <summary>
        /// 获取泌乳牛报表数据
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static string GetMilkCowData(string Farm_Id)
        {
            string Json_MilkCowData = string.Empty;
            string sql = string.Empty;

            if (Farm_Id != string.Empty)
            {
                sql = @"select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and ( FertilityStatus='产后未配') and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and (FertilityStatus='流产未配') and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and FertilityStatus='发情未配' and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and FertilityStatus='已配未检' and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and FertilityStatus='初检+' and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and FertilityStatus='初检-' and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and FertilityStatus='复检+' and IsOnFarm=1
                        union All
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='泌乳牛' and FertilityStatus='复检-' and IsOnFarm=1
                        ";
                DataSet dataset = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (dataset != null && dataset.Tables[0] != null)
                {
                    DataTable table = dataset.Tables[0]; //泌乳牛报表
                    if (table != null)
                    {
                        string MilkCow = table.Rows[0][0].ToString();
                        string NoInsem = table.Rows[1][0].ToString();
                        string Abortion = table.Rows[2][0].ToString();
                        string HeatNoInsem = table.Rows[3][0].ToString();
                        string Insem = table.Rows[4][0].ToString();
                        string PD1Positive = table.Rows[5][0].ToString();
                        string PD1Negative = table.Rows[6][0].ToString();
                        string PD2Positive = table.Rows[7][0].ToString();
                        string PD2Negative = table.Rows[8][0].ToString();
                        Json_MilkCowData = "{\"Name\":\"泌乳牛\",\"Value\":\"" + MilkCow + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"产后未配\",\"Value\":\"" + NoInsem + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"流产未配\",\"Value\":\"" + Abortion + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"发情未配\",\"Value\":\"" + HeatNoInsem + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"已配未检\",\"Value\":\"" + Insem + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"初检+\",\"Value\":\"" + PD1Positive + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"初检-\",\"Value\":\"" + PD1Negative + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"复检+\",\"Value\":\"" + PD2Positive + "\"}";
                        Json_MilkCowData += ",{\"Name\":\"复检-\",\"Value\":\"" + PD2Negative + "\"}";
                    }
                }

            }
            Json_MilkCowData = "\"MilkCowData\":[" + Json_MilkCowData + "]";
            return Json_MilkCowData;
        }

        #endregion

        #region 获取干奶牛报表数据
        /// <summary>
        /// 获取干奶牛报表数据
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static string GetDryCowData(string Farm_Id)
        {
            string Json_DryCowData = string.Empty;
            string sql = string.Empty;

            if (Farm_Id != string.Empty)
            {
                sql = @"select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and (FertilityStatus='发情未配' or FertilityStatus='产后未配')  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and (FertilityStatus='流产未配')  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and FertilityStatus='发情未配'  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and FertilityStatus='已配未检'  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and FertilityStatus='初检+'  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and FertilityStatus='初检-'  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and FertilityStatus='复检+'  and IsOnFarm=1
                        union all
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where GrowStatus='干奶牛' and FertilityStatus='复检-'  and IsOnFarm=1
                        ";
                DataSet dataset = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (dataset != null && dataset.Tables[0] != null)
                {
                    DataTable table = dataset.Tables[0]; //干奶牛报表
                    string DryCow = table.Rows[0][0].ToString();
                    string NoInsem = table.Rows[1][0].ToString();
                    string Abortion = table.Rows[2][0].ToString();
                    string HeatNoInsem = table.Rows[3][0].ToString();
                    string Insem = table.Rows[4][0].ToString();
                    string PD1Positive = table.Rows[5][0].ToString();
                    string PD1Negative = table.Rows[6][0].ToString();
                    string PD2Positive = table.Rows[7][0].ToString();
                    string PD2Negative = table.Rows[8][0].ToString();

                    Json_DryCowData = "{\"Name\":\"干奶牛\",\"Value\":\"" + DryCow + "\"}";
                    Json_DryCowData += ",{\"Name\":\"尚未配种\",\"Value\":\"" + NoInsem + "\"}";
                    Json_DryCowData += ",{\"Name\":\"流产未配\",\"Value\":\"" + Abortion + "\"}";
                    Json_DryCowData += ",{\"Name\":\"发情未配\",\"Value\":\"" + HeatNoInsem + "\"}";
                    Json_DryCowData += ",{\"Name\":\"已配未检\",\"Value\":\"" + Insem + "\"}";
                    Json_DryCowData += ",{\"Name\":\"初检+\",\"Value\":\"" + PD1Positive + "\"}";
                    Json_DryCowData += ",{\"Name\":\"初检-\",\"Value\":\"" + PD1Negative + "\"}";
                    Json_DryCowData += ",{\"Name\":\"复检+\",\"Value\":\"" + PD2Positive + "\"}";
                    Json_DryCowData += ",{\"Name\":\"复检-\",\"Value\":\"" + PD2Negative + "\"}";
                }

            }
            Json_DryCowData = "\"DryCowData\":[" + Json_DryCowData + "]";
            return Json_DryCowData;
        }

        #endregion

        #region 获取后备牛报表数据
        /// <summary>
        /// 获取后备牛报表数据
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static string GetHeiferData(string Farm_Id)
        {
            string Json_HeiferData = string.Empty;
            string sql = string.Empty;

            if (Farm_Id != string.Empty)
            {
                sql = @"--后备牛总数                     
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and GrowStatus!='留养公牛' and IsOnFarm=1
                        union all --出生
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and (FertilityStatus='出生')  and IsOnFarm=1
                        union all --流产
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and (FertilityStatus='流产未配')  and IsOnFarm=1
                        union all --发情未配
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and FertilityStatus='发情未配'  and IsOnFarm=1
                        union all --已配待检
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and FertilityStatus='已配未检'  and IsOnFarm=1
                        union all --初检+
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and FertilityStatus='初检+'  and IsOnFarm=1
                        union all --初检－
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and FertilityStatus='初检-'  and IsOnFarm=1
                        union all --复检+
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and FertilityStatus='复检+'  and IsOnFarm=1
                        union all --复检－
                        select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and FertilityStatus='复检-'  and IsOnFarm=1

                        ";
                DataSet dataset = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (dataset != null && dataset.Tables[0] != null)
                {
                    DataTable table = dataset.Tables[0]; //后备牛
                    string HeiferCow = table.Rows[0][0].ToString();
                    string NoInsem = table.Rows[1][0].ToString();
                    string Abortion = table.Rows[2][0].ToString();
                    string HeatNoInsem = table.Rows[3][0].ToString();
                    string Insem = table.Rows[4][0].ToString();
                    string PD1Positive = table.Rows[5][0].ToString();
                    string PD1Negative = table.Rows[6][0].ToString();
                    string PD2Positive = table.Rows[7][0].ToString();
                    string PD2Negative = table.Rows[8][0].ToString();

                    Json_HeiferData = "{\"Name\":\"后备牛\",\"Value\":\"" + HeiferCow + "\"}";
                    Json_HeiferData += ",{\"Name\":\"出生\",\"Value\":\"" + NoInsem + "\"}";
                    Json_HeiferData += ",{\"Name\":\"流产未配\",\"Value\":\"" + Abortion + "\"}";
                    Json_HeiferData += ",{\"Name\":\"发情未配\",\"Value\":\"" + HeatNoInsem + "\"}";
                    Json_HeiferData += ",{\"Name\":\"已配未检\",\"Value\":\"" + Insem + "\"}";
                    Json_HeiferData += ",{\"Name\":\"初检+\",\"Value\":\"" + PD1Positive + "\"}";
                    Json_HeiferData += ",{\"Name\":\"初检-\",\"Value\":\"" + PD1Negative + "\"}";
                    Json_HeiferData += ",{\"Name\":\"复检+\",\"Value\":\"" + PD2Positive + "\"}";
                    Json_HeiferData += ",{\"Name\":\"复检-\",\"Value\":\"" + PD2Negative + "\"}";
                }
            }
            Json_HeiferData = "\"HeiferData\":[" + Json_HeiferData + "]";
            return Json_HeiferData;
        }

        #endregion

        #region 获取成母牛报表数据
        /// <summary>
        /// 获取成母牛报表数据
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static string GetCowData(string Farm_Id)
        {
            string Json_CowData = string.Empty;
            string sql = string.Empty;

            if (Farm_Id != string.Empty)
            {
                sql = @"select
                 (                  
                select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber>0 and IsOnFarm=1
                ) as c1,
                (
                select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber=1  and IsOnFarm=1
                ) as c2,
                (
                select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber=2  and IsOnFarm=1
                ) as c3,
                (
                select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber>2  and IsOnFarm=1
                ) as c4,
                (
                --泌乳天数
                select case when count(cow_id)=0 then 0 else (SUM(MilkDay)*1.0/COUNT(Cow_Id)) end as c  from view_DairyBaseCow where MilkingStatus='泌乳' and IsOnFarm=1
                ) as c5,
                (
                select case when COUNT(c.Cow_Id)=0 then 0 else (SUM(Days)*1.0/COUNT(c.Cow_Id)) end as c 
                from DairyCow_Data_FirstinseminationDays f
                inner join view_DairyBaseCow c on f.Cow_Id=c.Cow_Id and f.LactationNumber=c.LactationNumber
                 and c.LactationNumber>0 
                ) as c6,
                (
                select case when COUNT(pid.Cow_Id)=0 then 0 else (SUM(Days)*1.0/COUNT(pid.Cow_Id)) end as c 
                from DairyCow_Data_PDInsemination pid
                inner join view_DairyBaseCow c on pid.Cow_Id=c.Cow_Id and pid.LactationNumber=c.LactationNumber
                where 
                pid.LactationNumber>0  
                ) as c7,
                (
                --胎间距
                select case when COUNT(ca.Cow_Id)=0 then 0 else (SUM(Days)*1.0/COUNT(ca.Cow_Id)) end as c from 
                DairyCow_Data_CalvingDaysSpan ca
                inner join view_DairyBaseCow c on ca.Cow_Id=c.Cow_Id and ca.LactationNumber=c.LactationNumber-1
                where --DATEDIFF(Month,pid.PDDate,GETDATE())=0 
                ca.LactationNumber>1
                ) as c8,
                (
                --怀孕%
                select
                (
                select COUNT(Cow_Id) as c from view_DairyBaseCow where 
                (FertilityStatus='初检+' or FertilityStatus='复检+') and LactationNumber>0 and IsOnFarm=1
                )*1.0
                /
                (
                select case when COUNT(Cow_Id)=0 then 0.1 else COUNT(Cow_Id) end as c from view_DairyBaseCow where LactationNumber>0 and IsOnFarm=1
                )*100
                ) as c9,
                (
                --配次大于等于6
                select COUNT(Cow_Id) as c from view_DairyBaseCow where InscminationNumber>=6 and IsOnFarm=1 and LactationNumber>0
                ) as c10,
                (
                --90天未配
                select COUNT(Cow_Id) as c from view_DairyBaseCow where MilkDay>90 and (InscminationNumber=0 or InscminationNumber is null) and LactationNumber>0  and IsOnFarm=1
                ) as c11,
                (
                --180天未孕
                select COUNT(Cow_Id) as c from view_DairyBaseCow where MilkDay>180 and (FertilityStatus!='初检+' and FertilityStatus!='复检+')
                and LactationNumber>0 and IsOnFarm=1
                ) as c12,
                (
                --待检
                select COUNT(Cow_Id) as c from view_DairyBaseCow where FertilityStatus='已配未检' and LactationNumber>0 and IsOnFarm=1
                ) as c13

                        ";
                DataSet dataset = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (dataset != null && dataset.Tables[0] != null)
                {
                    DataTable table = dataset.Tables[0]; //成母牛
                    DataRow row = table.Rows[0];
                    string Cow = row[0].ToString();
                    string Lac1 = row[1].ToString();
                    string Lac2 = row[2].ToString();
                    string Lac2AndMore = row[3].ToString();
                    string MilkDay = Math.Round(Double.Parse(row[4].ToString()), 2).ToString();
                    string FirstInsemDay = Math.Round(Double.Parse(row[5].ToString()), 2).ToString();
                    string PdInsemDay = Math.Round(Double.Parse(row[6].ToString()), 2).ToString();
                    string LacSapn = Math.Round(Double.Parse(row[7].ToString()), 2).ToString();
                    string PregRate = Math.Round(Double.Parse(row[8].ToString()), 2).ToString();
                    string InsemMoreThan6 = row[9].ToString();
                    string NoInsemMoreThan90D = row[10].ToString();
                    string NoPregnant6M = row[11].ToString();
                    string NoPdAfterInsem = row[12].ToString();

                    Json_CowData = "{\"Name\":\"成母牛\",\"Value\":\"" + Cow + "\"}";
                    Json_CowData += ",{\"Name\":\"1胎\",\"Value\":\"" + Lac1 + "\"}";
                    Json_CowData += ",{\"Name\":\"2胎\",\"Value\":\"" + Lac2 + "\"}";
                    Json_CowData += ",{\"Name\":\"2胎+\",\"Value\":\"" + Lac2AndMore + "\"}";
                    Json_CowData += ",{\"Name\":\"泌乳天数\",\"Value\":\"" + MilkDay + "\"}";
                    Json_CowData += ",{\"Name\":\"始配天数\",\"Value\":\"" + FirstInsemDay + "\"}";
                    Json_CowData += ",{\"Name\":\"配准天数\",\"Value\":\"" + PdInsemDay + "\"}";
                    Json_CowData += ",{\"Name\":\"胎间距\",\"Value\":\"" + LacSapn + "\"}";
                    Json_CowData += ",{\"Name\":\"怀孕%\",\"Value\":\"" + PregRate + "\"}";
                    Json_CowData += ",{\"Name\":\"配次≥6\",\"Value\":\"" + InsemMoreThan6 + "\"}";
                    Json_CowData += ",{\"Name\":\"90天未配\",\"Value\":\"" + NoInsemMoreThan90D + "\"}";
                    Json_CowData += ",{\"Name\":\"半年未孕\",\"Value\":\"" + NoPregnant6M + "\"}";
                    Json_CowData += ",{\"Name\":\"待检\",\"Value\":\"" + NoPdAfterInsem + "\"}";
                }

            }
            Json_CowData = "\"CowData\":[" + Json_CowData + "]";
            return Json_CowData;
        }

        #endregion

        #region 获取后备牛报表数据  另一个 跟前面的不一样
        /// <summary>
        /// 获取后备牛报表数据  另一个 跟前面的不一样
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static string GetAnotherHeiferData(string Farm_Id)
        {
            string Json_AnotherHeiferData = string.Empty;
            string sql = string.Empty;

            if (Farm_Id != string.Empty)
            {
                #region 首配月龄的SQL
                #endregion
                #region 超龄牛的SQL
                sql = @"select
                    (
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and  GrowStatus!='留养公牛' and IsOnFarm=1
                    ) as c1,
                    (
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and GrowStatus='哺乳犊牛' and IsOnFarm=1
                    ) as c2,
                    (
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and GrowStatus='断奶犊牛' and IsOnFarm=1
                    ) as c3,
                    (
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and GrowStatus='育成牛' and IsOnFarm=1
                    ) as c4,
                    (
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and GrowStatus='青年牛' and IsOnFarm=1
                    ) as c5,
                    (
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and GrowStatus='留养公牛' and IsOnFarm=1
                    ) as c6,
                    (
                    --超龄牛
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where LactationNumber<1 and MonthAge>=35 and IsOnFarm=1
                    ) as c7,
                    (
                    --配准月龄
                    select case when COUNT(pid.Cow_Id)=0 then 0 else (SUM(Days)/COUNT(pid.Cow_Id)/30.4) end as AvgPDInsemDay 
                    from DairyCow_Data_PDInsemination pid
                    inner join view_DairyBaseCow c on pid.Cow_Id=c.Cow_Id and pid.LactationNumber=c.LactationNumber
                    where 
                    c.LactationNumber=0
                    ) as c8,
                    ( 
                    --怀孕率
                    select
                    (
                    select case when COUNT(Cow_Id)=0 then 0.1 else COUNT(Cow_Id) end as c from view_DairyBaseCow where 
                    (FertilityStatus='初检+' or FertilityStatus='复检+') and LactationNumber=0 and IsOnFarm=1
                    )*1.0
                    /
                    (
                    select case when COUNT(Cow_Id)=0 then 0.1 else COUNT(Cow_Id) end as c from view_DairyBaseCow where LactationNumber=0 and IsOnFarm=1
                    )*100
                    ) as c9,
                    (
                    --配次大于等于6
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where InscminationNumber>=6 and IsOnFarm=1 and LactationNumber=0
                    ) as c10,
                    (
                    --19月龄未配
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where MonthAge>19 and (InscminationNumber=0 or InscminationNumber is null) and LactationNumber=0  and IsOnFarm=1
                    ) as c11,
                    (
                    --23月龄未孕
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where MonthAge>23 and (FertilityStatus!='初检+' and FertilityStatus!='复检+')
                    and LactationNumber=0 and IsOnFarm=1
                    ) as c12,
                    (
                    --待检
                    select COUNT(Cow_Id) as c from view_DairyBaseCow where FertilityStatus='已配未检' and LactationNumber=0 and IsOnFarm=1
                    ) as c13

                        ";
                #endregion
                DataSet dataset = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (dataset != null && dataset.Tables[0] != null)
                {
                    DataTable table = dataset.Tables[0]; //后备牛
                    DataRow row = table.Rows[0];
                    string Heifer = row[0].ToString();
                    string CalfOnMilk = row[1].ToString();
                    string CalfWeaned = row[2].ToString();
                    string SmallHeifer = row[3].ToString();
                    string BigHeifer = row[4].ToString();
                    string Bull = row[5].ToString();
                    string FirstInsemM = Math.Round(Double.Parse(row[6].ToString()), 2).ToString(); //超龄牛
                    string PdInsemM = Math.Round(Double.Parse(row[7].ToString()), 2).ToString();
                    string PregRate = Math.Round(Double.Parse(row[8].ToString()), 2).ToString();
                    string InsemMoreThan6 = row[9].ToString();
                    string NoInsemMoreThan19M = row[10].ToString();
                    string NoPregnantMoreThan23M = row[11].ToString();
                    string NoPdAfterInsem = row[12].ToString();

                    Json_AnotherHeiferData = "{\"Name\":\"后备牛\",\"Value\":\"" + Heifer + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"哺乳犊牛\",\"Value\":\"" + CalfOnMilk + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"断奶犊牛\",\"Value\":\"" + CalfWeaned + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"育成牛\",\"Value\":\"" + SmallHeifer + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"青年牛\",\"Value\":\"" + BigHeifer + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"留养公牛\",\"Value\":\"" + Bull + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"超龄牛\",\"Value\":\"" + FirstInsemM + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"配准月龄\",\"Value\":\"" + PdInsemM + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"怀孕%\",\"Value\":\"" + PregRate + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"配次≥6\",\"Value\":\"" + InsemMoreThan6 + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"19月龄未配\",\"Value\":\"" + NoInsemMoreThan19M + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"23月龄未孕\",\"Value\":\"" + NoPregnantMoreThan23M + "\"}";
                    Json_AnotherHeiferData += ",{\"Name\":\"待检\",\"Value\":\"" + NoPdAfterInsem + "\"}";
                }

            }
            Json_AnotherHeiferData = "\"AnotherHeiferData\":[" + Json_AnotherHeiferData + "]";
            return Json_AnotherHeiferData;
        }

        #endregion

        #endregion


        #region  牛群概貌 点击数字  显示明细

        #region 点击牛群概貌中的数字，获取牛只列表数据
        /// <summary>
        /// 点击牛群概貌中的数字，获取牛只列表数据 2012-02-21
        /// </summary>
        /// <param name="EarNum">牛号</param>
        /// <returns></returns>
        public static string GetCowList(int Kind, string Tag, int PageIndex, int PageSize, string OrderBy)
        {
            string Json_CowList = string.Empty; //牛只列表信息
            string Json_Result = string.Empty; //页码信息
            string Json_Title = "\"Title\":[{\"Name\":\"编号\"},{\"Name\":\"牛号\"},{\"Name\":\"组别\"},{\"Name\":\"胎次\"},{\"Name\":\"月龄\"},{\"Name\":\"泌乳天数\"},{\"Name\":\"繁殖状态\"},{\"Name\":\"配次\"},{\"Name\":\"配后天数\"}]";

            int CowCount = 0;
            int PageCount = 0;
            string Columns = "EarNum,Group_Name,LactationNumber,CONVERT(decimal(18,2),MonthAge) as MonthAge,MilkDay,FertilityStatus,InscminationNumber,AfterInsemDay";
            string Where = GetWhereByTag(Kind, Tag); //根据点击的链接获取Where条件
            Where += " and IsOnFarm=1 ";
            if (string.IsNullOrEmpty(OrderBy))
            {
                OrderBy = " EarNum ";
            }
            //获取这个where条件下有多少头牛
            string sql = "select count(*) as C from view_DairyBaseCow";
            if (!string.IsNullOrEmpty(Where))
            {
                sql = sql + " Where " + Where;
            }
            object objCowCount = SqlHelper.ExecuteScalar(sql);
            CowCount = int.Parse(objCowCount.ToString());
            PageCount = (int)Math.Ceiling(CowCount * 1.0 / PageSize);
            Json_Result = "\"Result\":{\"TotalCount\":\"" + CowCount + "\",\"TotalPageCount\":\"" + PageCount + "\"}";

            //获取分页查询后的牛只列表
            SqlDataReader reader = GetRecordListByPage("view_DairyBaseCow", PageIndex, PageSize, OrderBy, Where, Columns);


            while (reader.Read())
            {
                if (Json_CowList == string.Empty)
                {
                    Json_CowList = "{\"OrderNum\":\"" + reader["rowId"].ToString() + "\",";
                    Json_CowList += "\"EarNum\":\"" + reader["EarNum"].ToString() + "\",";
                    Json_CowList += "\"Group_Name\":\"" + reader["Group_Name"].ToString() + "\",";
                    Json_CowList += "\"LactationNumber\":\"" + reader["LactationNumber"].ToString() + "\",";
                    Json_CowList += "\"MonthAge\":\"" + reader["MonthAge"].ToString() + "\",";
                    Json_CowList += "\"MilkDay\":\"" + reader["MilkDay"].ToString() + "\",";
                    Json_CowList += "\"FertilityStatus\":\"" + reader["FertilityStatus"].ToString() + "\",";
                    Json_CowList += "\"InscminationNumber\":\"" + reader["InscminationNumber"].ToString() + "\",";
                    Json_CowList += "\"AfterInsemDay\":\"" + reader["AfterInsemDay"].ToString() + "\"}";
                }
                else
                {
                    Json_CowList += ",{\"OrderNum\":\"" + reader["rowId"].ToString() + "\",";
                    Json_CowList += "\"EarNum\":\"" + reader["EarNum"].ToString() + "\",";
                    Json_CowList += "\"Group_Name\":\"" + reader["Group_Name"].ToString() + "\",";
                    Json_CowList += "\"LactationNumber\":\"" + reader["LactationNumber"].ToString() + "\",";
                    Json_CowList += "\"MonthAge\":\"" + reader["MonthAge"].ToString() + "\",";
                    Json_CowList += "\"MilkDay\":\"" + reader["MilkDay"].ToString() + "\",";
                    Json_CowList += "\"FertilityStatus\":\"" + reader["FertilityStatus"].ToString() + "\",";
                    Json_CowList += "\"InscminationNumber\":\"" + reader["InscminationNumber"].ToString() + "\",";
                    Json_CowList += "\"AfterInsemDay\":\"" + reader["AfterInsemDay"].ToString() + "\"}";
                }
            }
            reader.Close();
            Json_CowList = "\"CowList\":[" + Json_CowList + "]";

            return "{" + Json_Result + "," + Json_Title + "," + Json_CowList + "}";
        }
        #endregion

        #region 根据点击的链接获取条件
        /// <summary>
        /// 根据点击的链接获取条件
        /// </summary>
        /// <param name="Tag">牛群概貌中的链接名称</param>
        /// <returns></returns>
        public static string GetWhereByTag(int Kind, string Tag)
        {
            string Where = string.Empty;
            #region  泌乳牛
            if (Kind == 1)
            {
                switch (Tag)
                {
                    case "泌乳牛":
                        Where = "GrowStatus='泌乳牛'";
                        break;
                    case "产后未配":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='产后未配'";
                        break;
                    case "流产未配 ":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='流产未配'";
                        break;
                    case "发情未配 ":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='发情未配'";
                        break;
                    case "已配未检":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='已配未检'";
                        break;
                    case "初检+":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='初检+'";
                        break;
                    case "初检-":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='初检-'";
                        break;
                    case "复检+":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='复检+'";
                        break;
                    case "复检-":
                        Where = "GrowStatus='泌乳牛' and FertilityStatus='复检-'";
                        break;
                    default:
                        Where = "1<>1";
                        break;
                }
            }
            #endregion
            #region 干奶牛
            else if (Kind == 2)
            {
                switch (Tag)
                {
                    case "干奶牛":
                        Where = "GrowStatus='干奶牛'";
                        break;
                    case "尚未配种":
                        Where = "GrowStatus='干奶牛' and (FertilityStatus='发情未配' or FertilityStatus='产后未配')";
                        break;
                    case "流产未配 ":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='流产未配'";
                        break;
                    case "发情未配 ":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='发情未配'";
                        break;
                    case "已配未检":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='已配未检'";
                        break;
                    case "初检+":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='初检+'";
                        break;
                    case "初检-":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='初检-'";
                        break;
                    case "复检+":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='复检+'";
                        break;
                    case "复检-":
                        Where = "GrowStatus='干奶牛' and FertilityStatus='复检-'";
                        break;
                    default:
                        Where = "1<>1";
                        break;
                }
            }
            #endregion
            #region 后备牛
            else if (Kind == 3)
            {
                switch (Tag)
                {
                    case "后备牛":
                        Where = "LactationNumber<1 and Gender='母'";
                        break;
                    case "出生":
                        Where = "LactationNumber<1 and FertilityStatus='出生'";
                        break;
                    case "流产未配 ":
                        Where = "LactationNumber<1  and FertilityStatus='流产未配'";
                        break;
                    case "发情未配 ":
                        Where = "LactationNumber<1  and FertilityStatus='发情未配'";
                        break;
                    case "已配未检":
                        Where = "LactationNumber<1  and FertilityStatus='已配未检'";
                        break;
                    case "初检+":
                        Where = "LactationNumber<1  and FertilityStatus='初检+'";
                        break;
                    case "初检-":
                        Where = "LactationNumber<1 GrowStatus='泌乳牛' and FertilityStatus='初检-'";
                        break;
                    case "复检+":
                        Where = "LactationNumber<1 GrowStatus='泌乳牛' and FertilityStatus='复检+'";
                        break;
                    case "复检-":
                        Where = "LactationNumber<1 GrowStatus='泌乳牛' and FertilityStatus='复检-'";
                        break;
                    default:
                        Where = "1<>1";
                        break;
                }
            }
            #endregion
            #region 成母牛
            else if (Kind == 4)
            {
                switch (Tag)
                {
                    case "成母牛":
                        Where = "LactationNumber>0";
                        break;
                    case "1胎":
                        Where = "LactationNumber=1";
                        break;
                    case "2胎":
                        Where = "LactationNumber=2";
                        break;
                    case "2胎+":
                        Where = "LactationNumber>2";
                        break;
                    case "怀孕%":
                        Where = "(FertilityStatus='初检+' or FertilityStatus='复检+') and LactationNumber>0'";
                        break;
                    case "配次≥6":
                        Where = "'InscminationNumber>=6  and LactationNumber>0";
                        break;
                    case "90天未配":
                        Where = "MilkDay>=90 and (InscminationNumber=0 or InscminationNumber is null) and LactationNumber>0";
                        break;
                    case "半年未孕":
                        Where = "MilkDay>=180 and (FertilityStatus!='初检+' and FertilityStatus!='复检+') and LactationNumber>0'";
                        break;
                    case "待检":
                        Where = "FertilityStatus='已配未检' and LactationNumber>0";
                        break;
                    default:
                        Where = "1<>1";
                        break;
                }
            }
            #endregion
            #region 后备牛 最后一个
            else if (Kind == 5)
            {
                switch (Tag)
                {
                    case "后备牛":
                        Where = "LactationNumber<1 and Gender='母'";
                        break;
                    case "哺乳犊牛":
                        Where = "LactationNumber<1 and GrowStatus='哺乳犊牛'";
                        break;
                    case "断奶犊牛":
                        Where = "LactationNumber<1 and GrowStatus='断奶犊牛'";
                        break;
                    case "育成牛":
                        Where = "LactationNumber<1 and GrowStatus='育成牛'";
                        break;
                    case "青年牛":
                        Where = "LactationNumber<1 and GrowStatus='青年牛'";
                        break;
                    case "留养公牛":
                        Where = "LactationNumber<1 and GrowStatus='留养公牛'";
                        break;
                    case "超龄牛":
                        Where = "LactationNumber<1 and MonthAge>=35";
                        break;
                    case "怀孕%":
                        Where = "(FertilityStatus='初检+' or FertilityStatus='复检+') and LactationNumber=0";
                        break;
                    case "配次≥6":
                        Where = "InscminationNumber>=6  and LactationNumber=0";
                        break;
                    case "19月龄未配":
                        Where = "MonthAge>=19  and (InscminationNumber=0 or InscminationNumber is null) and LactationNumber=0";
                        break;
                    case "23月龄未孕":
                        Where = "MonthAge>=23 and (FertilityStatus!='初检+' and FertilityStatus!='复检+') and LactationNumber=0";
                        break;
                    case "待检":
                        Where = "FertilityStatus='已配未检' and LactationNumber=0";
                        break;
                    default:
                        Where = "1<>1";
                        break;
                }
            }
            #endregion
            return Where;
        }
        #endregion

        #region 根据where条件和页码大小和第几页等信息分页查询牛只列表 2012-02-22
        /// <summary>
        /// 根据where条件和页码大小和第几页等信息分页查询牛只列表
        /// </summary>
        /// <param name="Tag"></param>
        /// <returns></returns>
        public static SqlDataReader GetRecordListByPage(string TableName, int PageIndex, int PageSize, string OrderBy, string Where, string Columns)
        {

            SqlParameter[] arParams = new SqlParameter[10];
            arParams[0] = new SqlParameter("@tblName", TableName);
            arParams[1] = new SqlParameter("@Columns", Columns);
            arParams[2] = new SqlParameter("@SumColumnNames", "");
            arParams[3] = new SqlParameter("@IsSumAll", SqlDbType.TinyInt);
            arParams[3].Value = 0;
            arParams[4] = new SqlParameter("@OrderField", OrderBy);
            arParams[5] = new SqlParameter("@strWhere", Where);
            arParams[6] = new SqlParameter("@PageSize", PageSize);
            arParams[7] = new SqlParameter("@PageIndex", PageIndex);
            arParams[8] = new SqlParameter("@PageCount", SqlDbType.Int);
            arParams[8].Direction = ParameterDirection.Output;
            arParams[9] = new SqlParameter("@SumResult", SqlDbType.NVarChar, 200);
            arParams[9].Direction = ParameterDirection.Output;
            SqlDataReader reader = SqlHelper.ExecuteReader(CommandType.StoredProcedure, "sp_CommonDataSource", arParams);

            //object objPageCount = arParams[8].SqlValue;


            return reader;
        }
        #endregion

        #endregion

        #region  获取近3天的事件汇总 2012-02-22

        #region  获取近3天的事件汇总报表数据
        /// <summary>
        /// 获取近3天的事件汇总报表数据
        /// </summary>
        /// <param name="CurrentDay"></param>
        /// <returns></returns>
        public static string GetEventReportData(string CurrentDay)
        {
            string Json_EventReportData = string.Empty;
            string Json_Result = string.Empty;
            DateTime dtCur = new DateTime();
            DateTime dtLastDay = new DateTime();
            DateTime dtTheDayBeforeLastDay = new DateTime();
            if (DateTime.TryParse(CurrentDay, out dtCur) == true)
            {
                dtLastDay = dtCur.Date.AddDays(-1);
                dtTheDayBeforeLastDay = dtLastDay.Date.AddDays(-1);

                Json_Result = "\"Result\":{\"CurrentDay\":\"" + dtCur.ToShortDateString() + "\",\"LastDay\":\"" + dtLastDay.ToShortDateString() + "\",\"TheDayBeforeLastDay\":\"" + dtTheDayBeforeLastDay.ToShortDateString() + "\"}";

                string sql = @"select t.Events_Code,t.Events_Name,ISNULL(cd.C,0) as CurrentDay,ISNULL(ld.C,0) as LastDay,ISNULL(ll.C,0) as TheDayBeforeLastDay  from DairyCow_EventType t 
                                left join
                                (
                                select Events_Code,COUNT(*) as C from View_EventsAll where datediff(day,EventsDate,'{0}')=0 group by Events_Code
                                ) as cd on t.Events_Code=cd.Events_Code
                                left join
                                (
                                select Events_Code,COUNT(*) as C from View_EventsAll where datediff(day,EventsDate,'{1}')=0 group by Events_Code
                                ) as ld on t.Events_Code=ld.Events_Code
                                left join
                                (
                                select Events_Code,COUNT(*) as C from View_EventsAll where datediff(day,EventsDate,'{2}')=0 group by Events_Code
                                ) as ll on t.Events_Code=ll.Events_Code
                                order by t.OrderNum desc";
                sql = string.Format(sql, dtCur, dtLastDay, dtTheDayBeforeLastDay);

                DataSet ds = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable table = ds.Tables[0];
                    foreach (DataRow row in table.Rows)
                    {
                        if (Json_EventReportData == string.Empty)
                        {
                            Json_EventReportData = "{\"EventCode\":\"" + row["Events_Code"].ToString() + "\",";
                            Json_EventReportData += "\"EventName\":\"" + row["Events_Name"].ToString() + "\",";
                            Json_EventReportData += "\"CurrentDay\":\"" + row["CurrentDay"].ToString() + "\",";
                            Json_EventReportData += "\"LastDay\":\"" + row["LastDay"].ToString() + "\",";
                            Json_EventReportData += "\"TheDayBeforeLastDay\":\"" + row["TheDayBeforeLastDay"].ToString() + "\"}";
                        }
                        else
                        {
                            Json_EventReportData += ",{\"EventCode\":\"" + row["Events_Code"].ToString() + "\",";
                            Json_EventReportData += "\"EventName\":\"" + row["Events_Name"].ToString() + "\",";
                            Json_EventReportData += "\"CurrentDay\":\"" + row["CurrentDay"].ToString() + "\",";
                            Json_EventReportData += "\"LastDay\":\"" + row["LastDay"].ToString() + "\",";
                            Json_EventReportData += "\"TheDayBeforeLastDay\":\"" + row["TheDayBeforeLastDay"].ToString() + "\"}";
                        }
                    }
                }
            }
            Json_EventReportData = "{" + Json_Result + ",\"EventReportData\":[" + Json_EventReportData + "]}";
            return Json_EventReportData;
        }
        #endregion

        #region  事件汇总明细数据
        /// <summary>
        /// 事件汇总明细数据
        /// </summary>
        /// <param name="CurrentDay"></param>
        /// <param name="Events_Name"></param>
        /// <returns></returns>
        public static string GetEventReportDetails(string CurrentDay, string Events_Name, int PageIndex, int PageSize, string OrderBy)
        {
            string Json_EventData = string.Empty;//事件信息
            string Json_Title = string.Empty; //标题
            string Json_Result = string.Empty; //页码信息



            DateTime dtCur = new DateTime();
            if (DateTime.TryParse(CurrentDay, out dtCur) == true)
            {
                Json_Title = "\"Title\":[{\"Name\":\"事件名称\"},{\"Name\":\"牛号\"},{\"Name\":\"日期\"},{\"Name\":\"描述\"}]";

                string TableName = "View_EventsAll";
                string Columns = "Events_Name,EarNum,CONVERT(date,EventsDate) as EventsDate,EventDescription";
                string Where = "Events_Code=(select Events_Code from DairyCow_EventType where Events_Name='" + Events_Name + "') and DATEDIFF(DAY,EventsDate,'" + CurrentDay + "')=0";
                int RecordCount = 0;
                int PageCount = 0;
                if (string.IsNullOrEmpty(OrderBy))
                {
                    OrderBy = "EarNum Desc ";
                }

                string sql = @"select count(*)  from " + TableName + " where " + Where;
                object objRecordCount = SqlHelper.ExecuteScalar(sql);
                RecordCount = int.Parse(objRecordCount.ToString());
                PageCount = (int)Math.Ceiling(RecordCount * 1.0 / PageSize);
                Json_Result = "\"Result\":{\"TotalCount\":\"" + RecordCount + "\",\"TotalPageCount\":\"" + PageCount + "\"}";



                SqlDataReader reader = GetRecordListByPage(TableName, PageIndex, PageSize, OrderBy, Where, Columns);
                while (reader.Read())
                {
                    if (Json_EventData == string.Empty)
                    {
                        Json_EventData = "{\"EventName\":\"" + reader["Events_Name"].ToString() + "\",";
                        Json_EventData += "\"EarNum\":\"" + reader["EarNum"].ToString() + "\",";
                        Json_EventData += "\"EventsDate\":\"" + reader["EventsDate"].ToString() + "\",";
                        Json_EventData += "\"EventDescription\":\"" + reader["EventDescription"].ToString() + "\"}";
                    }
                    else
                    {
                        Json_EventData += ",{\"EventName\":\"" + reader["Events_Name"].ToString() + "\",";
                        Json_EventData += "\"EarNum\":\"" + reader["EarNum"].ToString() + "\",";
                        Json_EventData += "\"EventsDate\":\"" + reader["EventsDate"].ToString() + "\",";
                        Json_EventData += "\"EventDescription\":\"" + reader["EventDescription"].ToString() + "\"}";
                    }
                }
            }
            Json_EventData = "{" + Json_Result+"," + Json_Title + ",\"EventsReportData\":[" + Json_EventData + "]}";
            return Json_EventData;
        }
        #endregion

        #endregion

        #region  所有的预警项目 2012-02-22

        #region  获取或有的预警项目
        /// <summary>
        /// 获取或有的预警项目  固定的几项预警
        /// </summary>
        /// <param name="CurrentDay"></param>
        /// <returns></returns>
        public static string GetEarlyWarningData()
        {
            string Json_EarlyWarningData = string.Empty;
            string sql = @"select
                        0 as FQN,
                        (
                        select count(Cow_Id) from view_DairyBaseCow b where AfterInsemDay>=40 and FertilityStatus='已配未检' 
                        and IsOnFarm=1
                        ) as CJTZ,
                        (
                        select count(Cow_Id) from view_DairyBaseCow b
                        where PregantDays>=220 and LactationNumber>0 and GrowStatus='泌乳牛' 
                        and FertilityStatus in('初检+','复检+')
                        and IsOnFarm=1
                        ) as GNTZ,
                        (
                        select count(Cow_Id) from view_DairyBaseCow b
                        where BeforeCalvingDay<=10 and IsOnFarm=1 and FertilityStatus like '%+%'
                        ) as LCTZ,
                        (
                        select count(Cow_Id) from view_DairyBaseCow b where 
                        AfterInsemDay>90
                        and (FertilityStatus='初检+')  
                        and IsOnFarm=1
                        ) as FJTZ,
                        (select count(Cow_Id) from view_DairyBaseCow b
                        where DayAge>=60  and not exists (select Wean_Id from DairyCow_Wean where Cow_Id=b.Cow_Id )
                        and IsOnFarm=1
                        ) as DNTZ";
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                Json_EarlyWarningData = "{\"Name\":\"发情牛\",\"Value\":\"" + reader["FQN"].ToString() + "\"}";
                Json_EarlyWarningData += ",{\"Name\":\"初检通知\",\"Value\":\"" + reader["CJTZ"].ToString() + "\"}";
                Json_EarlyWarningData += ",{\"Name\":\"干奶通知\",\"Value\":\"" + reader["GNTZ"].ToString() + "\"}";
                Json_EarlyWarningData += ",{\"Name\":\"临产通知\",\"Value\":\"" + reader["LCTZ"].ToString() + "\"}";
                Json_EarlyWarningData += ",{\"Name\":\"复检通知\",\"Value\":\"" + reader["FJTZ"].ToString() + "\"}";
                Json_EarlyWarningData += ",{\"Name\":\"断奶通知\",\"Value\":\"" + reader["DNTZ"].ToString() + "\"}";
            }
            reader.Close();

            Json_EarlyWarningData = "\"EarlyWarningData\":[" + Json_EarlyWarningData + "]";

            return Json_EarlyWarningData;
        }
        #endregion

        #region  获取预警中的牛只明细数据
        /// <summary>
        /// 获取预警中的牛只明细数据
        /// </summary>
        /// <param name="CurrentDay"></param>
        /// <param name="Events_Name"></param>
        /// <returns></returns>
        public static string GetEarlyWarningCowList(string CurrentDay, string Events_Name)
        {
            string Json_EventData = string.Empty;
            string Json_Title = string.Empty;
            DateTime dtCur = new DateTime();
            if (DateTime.TryParse(CurrentDay, out dtCur) == true)
            {
                Json_Title = "\"Title\":[{\"Name\":\"事件名称\"},{\"Name\":\"牛号\"},{\"Name\":\"日期\"},{\"Name\":\"描述\"}]";

                string sql = @"select Events_Name,EarNum,CONVERT(date,EventsDate) as EventsDate,EventDescription from View_EventsAll where Events_Code=(select Events_Code from DairyCow_EventType where Events_Name='" + Events_Name + "')";

                DataSet ds = SqlHelper.ExecuteDataset(CommandType.Text, sql);
                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable table = ds.Tables[0];
                    foreach (DataRow row in table.Rows)
                    {
                        if (Json_EventData == string.Empty)
                        {
                            Json_EventData = "{\"EventName\":\"" + row["Events_Name"].ToString() + "\",";
                            Json_EventData += "\"EarNum\":\"" + row["EarNum"].ToString() + "\",";
                            Json_EventData += "\"EventDate\":\"" + row["EventDate"].ToString() + "\",";
                            Json_EventData += "\"EventDescription\":\"" + row["EventDescription"].ToString() + "\"}";
                        }
                        else
                        {
                            Json_EventData += ",{\"EventName\":\"" + row["Events_Name"].ToString() + "\",";
                            Json_EventData += "\"EarNum\":\"" + row["EarNum"].ToString() + "\",";
                            Json_EventData += "\"EventDate\":\"" + row["EventDate"].ToString() + "\",";
                            Json_EventData += "\"EventDescription\":\"" + row["EventDescription"].ToString() + "\"}";
                        }
                    }
                }
            }
            Json_EventData = "{" + Json_Title + ",\"EventsReportData\":[" + Json_EventData + "]}";
            return Json_EventData;
        }
        #endregion

        #endregion

        #region  预警 点击数字  显示明细

        #region 点击牛群概貌中的数字，获取牛只列表数据
        /// <summary>
        /// 点击牛群概貌中的数字，获取牛只列表数据 2012-02-21
        /// </summary>
        /// <param name="EarNum">牛号</param>
        /// <returns></returns>
        public static string GetEarlyWarningCowList(string ProjectName, int PageIndex, int PageSize, string OrderBy)
        {
            string Json_CowList = string.Empty; //牛只列表信息
            string Json_Result = string.Empty; //页码信息
            string Json_Title = "\"Title\":[{\"Name\":\"编号\"},{\"Name\":\"牛号\"},{\"Name\":\"组别\"},{\"Name\":\"胎次\"},{\"Name\":\"月龄\"},{\"Name\":\"泌乳天数\"},{\"Name\":\"繁殖状态\"},{\"Name\":\"配次\"},{\"Name\":\"配后天数\"}]";

            int CowCount = 0;
            int PageCount = 0;
            string Columns = "EarNum,Group_Name,LactationNumber,MonthAge,MilkDay,FertilityStatus,InscminationNumber,AfterInsemDay";
            string Where = GetWhereByEarlyWarningProject(ProjectName); //根据点击的链接获取Where条件
            if (string.IsNullOrEmpty(OrderBy))
            {
                OrderBy = " EarNum ";
            }
            //获取这个where条件下有多少头牛
            string sql = "select count(*) as C from view_DairyBaseCow";
            if (!string.IsNullOrEmpty(Where))
            {
                sql = sql + " Where " + Where;
            }
            object objCowCount = SqlHelper.ExecuteScalar(sql);
            CowCount = int.Parse(objCowCount.ToString());
            PageCount = (int)Math.Ceiling(CowCount * 1.0 / PageSize);
            //获取分页查询后的牛只列表
            SqlDataReader reader = GetRecordListByPage("view_DairyBaseCow", PageIndex, PageSize, OrderBy, Where, Columns);

            Json_Result = "\"Result\":{\"TotalCount\":\"" + CowCount + "\",\"TotalPageCount\":\"" + PageCount + "\"}";
            while (reader.Read())
            {
                if (Json_CowList == string.Empty)
                {
                    Json_CowList = "{\"OrderNum\":\"" + reader["rowId"].ToString() + "\",";
                    Json_CowList += "\"EarNum\":\"" + reader["EarNum"].ToString() + "\",";
                    Json_CowList += "\"Group_Name\":\"" + reader["Group_Name"].ToString() + "\",";
                    Json_CowList += "\"LactationNumber\":\"" + reader["LactationNumber"].ToString() + "\",";
                    Json_CowList += "\"MonthAge\":\"" + reader["MonthAge"].ToString() + "\",";
                    Json_CowList += "\"MilkDay\":\"" + reader["MilkDay"].ToString() + "\",";
                    Json_CowList += "\"FertilityStatus\":\"" + reader["FertilityStatus"].ToString() + "\",";
                    Json_CowList += "\"InscminationNumber\":\"" + reader["InscminationNumber"].ToString() + "\",";
                    Json_CowList += "\"AfterInsemDay\":\"" + reader["AfterInsemDay"].ToString() + "\"}";
                }
                else
                {
                    Json_CowList += ",{\"OrderNum\":\"" + reader["rowId"].ToString() + "\",";
                    Json_CowList += "\"EarNum\":\"" + reader["EarNum"].ToString() + "\",";
                    Json_CowList += "\"Group_Name\":\"" + reader["Group_Name"].ToString() + "\",";
                    Json_CowList += "\"LactationNumber\":\"" + reader["LactationNumber"].ToString() + "\",";
                    Json_CowList += "\"MonthAge\":\"" + reader["MonthAge"].ToString() + "\",";
                    Json_CowList += "\"MilkDay\":\"" + reader["MilkDay"].ToString() + "\",";
                    Json_CowList += "\"FertilityStatus\":\"" + reader["FertilityStatus"].ToString() + "\",";
                    Json_CowList += "\"InscminationNumber\":\"" + reader["InscminationNumber"].ToString() + "\",";
                    Json_CowList += "\"AfterInsemDay\":\"" + reader["AfterInsemDay"].ToString() + "\"}";
                }
            }
            reader.Close();
            Json_CowList = "\"CowList\":[" + Json_CowList + "]";

            return "{" + Json_Result + "," + Json_Title + "," + Json_CowList + "}";
        }
        #endregion

        #region 根据点击的链接获取条件
        /// <summary>
        /// 根据点击的链接获取条件
        /// </summary>
        /// <param name="Tag">牛群概貌中的链接名称</param>
        /// <returns></returns>
        public static string GetWhereByEarlyWarningProject(string ProjectName)
        {
            string Where = string.Empty;

            switch (ProjectName)
            {
                case "发情牛":
                    Where = "1<>1";
                    break;
                case "初检通知":
                    Where = "AfterInsemDay>=40 and FertilityStatus='已配未检' and IsOnFarm=1";
                    break;
                case "干奶通知":
                    Where = "PregantDays>=220 and LactationNumber>0 and IsOnFarm=1  and GrowStatus='泌乳牛' and FertilityStatus in('初检+','复检+')";
                    break;
                case "临产通知":
                    Where = "BeforeCalvingDay<=10 and IsOnFarm=1 and FertilityStatus like '%+%'";
                    break;
                case "复检通知":
                    Where = "AfterInsemDay>90 and FertilityStatus='初检+' and IsOnFarm=1";
                    break;
                case "断奶通知":
                    Where = "DayAge>=60  and not exists (select Wean_Id from DairyCow_Wean where Cow_Id=t.Cow_Id ) and IsOnFarm=1";
                    break;
            }

            return Where;
        }
        #endregion

        #endregion

        #region 验证牛是否存在
        /// <summary>
        /// 验证牛是否存在 2012-02-21
        /// </summary>
        /// <param name="EarNum">牛号</param>
        /// <returns></returns>
        public static string IsExists(string EarNum)
        {
            string Json_BasicData = string.Empty; //基本信息

            string sql = @"select Cow_Id from Base_Cow where EarNum='" + EarNum + "'";
            SqlDataReader reader = SqlHelper.ExecuteReader(sql);
            if (reader.Read())
            {
                Json_BasicData = "{\"Result\": {\"IsExits\": \"1\"}}";
            }
            else {
                Json_BasicData = "{\"Result\": {\"IsExits\": \"0\"}}";
            }
            reader.Close();

            return Json_BasicData;
        }
        #endregion
    }
}
