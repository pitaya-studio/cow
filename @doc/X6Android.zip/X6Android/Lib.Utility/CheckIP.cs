#region 
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
#endregion

namespace Lib.Utility
{
  public class CheckIP
  {
    #region ��ȡ��ʵIP
    /// <summary>
    /// ��ȡ��ʵIP
    /// </summary>
    /// <returns>����IP�ַ���</returns>
    public string GetRealIP()
    {
      string ip;
      try
      {
        HttpRequest request = HttpContext.Current.Request;

        if (request.ServerVariables["HTTP_VIA"] != null)
        {
          ip = request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString().Split(',')[0].Trim();
        }
        else
        {
          ip = request.UserHostAddress;
        }
      }
      catch (Exception e)
      {
        throw e;
      }

      return ip;
    }
    #endregion

    #region ��IP��ַ��ʽ��Ϊ������ IpToInt(string ip)
    /// <summary> 
    /// ��IP��ַ��ʽ��Ϊ������ 
    /// </summary> 
    /// <param name="ip"></param> 
    /// <returns></returns> 
    public long IpToInt(string ip)
    {
      char[] dot = new char[] { '.' };
      string[] ipArr = ip.Split(dot);
      if (ipArr.Length == 3)
        ip = ip + ".0";
      ipArr = ip.Split(dot);

      long ip_Int = 0;
      long p1 = long.Parse(ipArr[0]) * 256 * 256 * 256;
      long p2 = long.Parse(ipArr[1]) * 256 * 256;
      long p3 = long.Parse(ipArr[2]) * 256;
      long p4 = long.Parse(ipArr[3]);
      ip_Int = p1 + p2 + p3 + p4;
      return ip_Int;
    }
    #endregion

    #region �ж�IP�Ƿ�Ϊ����IP
    /// <summary>
    /// ��ȡ��ʵIP
    /// </summary>
    /// <returns>����IP�ַ���</returns>
    public bool DoCheckIP(string GetIP)
    {
      string CheckIP = System.Configuration.ConfigurationManager.AppSettings["CheckIP"];
      if (string.IsNullOrEmpty(CheckIP)) return false;

      string[] CheckIPArr = Func.SplitString(CheckIP, ";");
      bool ok = false;
      long intIP = this.IpToInt(GetIP);

      for (int i = 0; i < CheckIPArr.Length; i++)
      {
        string[] scaleIP = Func.SplitString(CheckIPArr[i]);
        if (scaleIP.Length < 2) continue;

        if (intIP >= this.IpToInt(scaleIP[0]) && intIP <= this.IpToInt(scaleIP[1]))
          ok = true;
      }

      return ok;
    }

    public bool DoCheckIP()
    {
      return DoCheckIP(GetRealIP());
    }
    #endregion
  }
}
