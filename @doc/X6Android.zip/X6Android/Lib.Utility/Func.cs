#region 
using System;
using System.Data;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Globalization;
#endregion

namespace Lib.Utility
{
	public abstract class Func
	{
		#region ע��ű�
		public static string getAlertScript(string msg)
		{
			StringBuilder script=new StringBuilder();
			script.Append("<script language='javascript'>\n");
			script.Append("function msgBoxAlert(){\n");
			script.Append("alert('" + msg + "');\n");
			script.Append("};\n");
			script.Append("</script>\n");
			script.Append("<script language='javascript' event='onload' for='window'>\n");
			script.Append("msgBoxAlert();\n");
			script.Append("</script>\n");
      return script.ToString();
		}
		/// <summary>
		/// д��ͻ��˽ű����
		/// </summary>
		/// <param name="msg"></param>
		/// <returns>StringBuilder�ַ���</returns>
		public static string GetScript(string msg)
		{
			StringBuilder script=new StringBuilder();
			script.Append("<script language='javascript'>\n");
			script.Append("function msgScript(){\n");
			script.Append(msg);
			script.Append("}\n");
			script.Append("</script>\n");
			script.Append("<script language='javascript' event='onload' for='window'>\n");
			script.Append("msgScript();\n");
			script.Append("</script>\n");
			return script.ToString();
		}
		public static string GetScriptOnLoad(string msg)
		{
			StringBuilder script=new StringBuilder();
			script.Append("<script language='javascript'>\n");
			script.Append("function msgScript(){\n");
			script.Append(msg);
			script.Append("}\n");
			script.Append("</script>\n");
			script.Append("<script language='javascript' event='onload' for='window'>\n");
			script.Append("msgScript();\n");
			script.Append("</script>\n");
			return script.ToString();
		}
		public static string GetScriptNonEvent(string msg)
		{
			StringBuilder script=new StringBuilder();
			script.Append("<script language='javascript'>\n");
			script.Append(msg);
			script.Append("</script>\n");
			return script.ToString();
		}
		/// <summary>
		/// д��رմ���Ľű�����������ͬʱˢ��
		/// </summary>
		/// <param name="msg"></param>
		/// <returns></returns>
		public static string GetCloseWindowScript()
		{
			StringBuilder script=new StringBuilder();
			script.Append("<script language='javascript'>\n");
			script.Append("function CloseWin(){\n");
			script.Append("self.close();\n");
			script.Append("self.opener.location.reload();\n");
			script.Append("};\n");
			script.Append("</script>\n");
			script.Append("<script language='javascript' event='onload' for='window'>\n");
			script.Append("CloseWin();\n");
			script.Append("</script>\n");
			return script.ToString();
		}
		/// <summary>
		/// д��ű�msgbox(msg)�����巵��
		/// </summary>
		/// <param name="msg"></param>
		/// <returns></returns>
		public static string getAlertAndGoBackScript(string msg)
		{
			StringBuilder script=new StringBuilder();
			script.Append("<script language='javascript'>\n");
			script.Append("function msgAlertBox(){\n");
			script.Append("alert('" + msg + "');\n");
			script.Append("window.history.go(-2);\n");
			script.Append("};\n");
			script.Append("</script>\n");
			script.Append("<script language='javascript' event='onload' for='window'>\n");
			script.Append("msgBox();\n");
			script.Append("</script>\n");
			return script.ToString();
		}
		#endregion

		#region ��ѡ��Ĵ���
		public static string GetRblValue(System.Web.UI.WebControls.RadioButtonList RBList)
		{
			string reVal=null;
			try
			{
				reVal=RBList.SelectedValue;
				return reVal;
			}
			catch
			{
				return null;
			}
		}
		public static void SetRBListValue(System.Web.UI.WebControls.RadioButtonList RBList, string selectedValue)
		{
			try
			{
				for(int i=0;i<RBList.Items.Count;i++)
					if(RBList.Items[i].Value==selectedValue)
					{
						RBList.Items[i].Selected=true;
						break;
					}
			}
			catch
			{
				return;
			}
		}

		#endregion

		#region ������Ĵ���
		/// <summary>
		/// ����������ֵ
		/// </summary>
		/// <param name="DDList"></param>
		/// <returns></returns>
		public static string getDDListValue(System.Web.UI.WebControls.DropDownList DDList)
		{
			string reVal=null;
			try
			{
				for(int i=0;i<DDList.Items.Count;i++)
					if(DDList.Items[i].Selected)
					{
						reVal=DDList.Items[i].Value;
						break;
					}
				return reVal;
			}
			catch
			{
				return null;
			}
		}
		/// <summary>
		/// �趨�������ֵ
		/// </summary>
		/// <param name="DDList"></param>
		/// <returns></returns>
		public static void SetDDListValue(System.Web.UI.WebControls.DropDownList DDList, string selectedValue)
		{
			try
			{
				for(int i=0;i<DDList.Items.Count;i++)
					if(DDList.Items[i].Value==selectedValue)
					{
						DDList.Items[i].Selected=true;
						break;
					}
			}
			catch
			{
				return;
			}
		}
		/// <summary>
		/// �趨��������ı�
		/// </summary>
		/// <param name="DDList"></param>
		/// <returns></returns>
		public static void SetDDListText(System.Web.UI.WebControls.DropDownList DDList, string selectedText)
		{
			try
			{
				for(int i=0;i<DDList.Items.Count;i++)
					if(DDList.Items[i].Text==selectedText)
					{
						DDList.Items[i].Selected=true;
						break;
					}
			}
			catch
			{
				return;
			}
		}
		/// <summary>
		/// �趨��������ı�
		/// </summary>
		/// <param name="DDList"></param>
		/// <returns></returns>
		public static void SetListBoxValue(System.Web.UI.WebControls.ListBox listBox, string selectedValue)
		{
			try
			{
				for(int i=0;i<listBox.Items.Count;i++)
					if(listBox.Items[i].Value==selectedValue)
					{
						listBox.Items[i].Selected=true;
						break;
					}
			}
			catch
			{
				return;
			}
		}
		public static void SetCheckBoxValue(System.Web.UI.WebControls.CheckBoxList checkBoxList, string selectedValue)
		{
			try
			{
				for(int i=0;i<checkBoxList.Items.Count;i++)
					if(checkBoxList.Items[i].Value==selectedValue)
					{
						checkBoxList.Items[i].Selected=true;
						break;
					}
			}
			catch
			{
				return;
			}
		}
		public static void SetRadiosValue(System.Web.UI.WebControls.RadioButtonList radios, string selectedValue)
		{
			try
			{
				for(int i=0;i<radios.Items.Count;i++)
					if(radios.Items[i].Value==selectedValue)
					{
						radios.Items[i].Selected=true;
						break;
					}
			}
			catch
			{
				return;
			}
		}
		#endregion

		#region ����html
		/// <summary>
		/// �� 'תΪ&apos;�س�����ȥ
		/// </summary>
		/// <param name="sender"></param>
		/// <returns></returns>
		public static StringBuilder EnCode(string sender)
		{
			StringBuilder sb=new StringBuilder(sender);
			sb.Replace("'","&apos;");
			sb.Replace("\n","");
			return sb;
		}
		/// <summary>
		/// �� &apos;��\r\nתΪ'���س���
		/// </summary>
		/// <param name="sender"></param>
		/// <returns></returns>
		public static StringBuilder DeCode(string sender)
		{
			StringBuilder sb=new StringBuilder(sender);
			sb.Replace("\r","\r\n");
			sb.Replace("'","&apos;");
			return sb;
		}
		/// <summary>
		/// ת�����������ܡ���������\r\n תΪ&lt;��&gt;����quote;��&amp;����br��
		/// </summary>
		/// <param name="sender"></param>
		/// <returns></returns>
		public static StringBuilder EnCode2(string sender)
		{
			StringBuilder sb=new StringBuilder(sender);
			sb.Replace("<","&lt;");
			sb.Replace(">","&gt;");
			sb.Replace("\"","&quote;");
			sb.Replace("'","&apos;");
			sb.Replace("&","&amp;");
			sb.Replace("\r\n","<br>");
			return sb;
		}
		/// <summary>
		/// &lt;��&gt;��&quote;��&amp;����br��תΪ���������ܡ���������\r\n 
		/// </summary>
		/// <param name="sender"></param>
		/// <returns></returns>
		public static StringBuilder DeCode2(string sender)
		{
			StringBuilder sb=new StringBuilder(sender);
			sb.Replace("&lt;","<");
			sb.Replace("&gt;",">");
			sb.Replace("&quote;","\"");
			sb.Replace("&apos;","'");
			sb.Replace("&amp;","&");
			sb.Replace("<br>","\r\n");
			return sb;
		}
		/// <summary>
		/// ����HTML����������תΪ&apos;���س���תΪ&lt;br&gt;
		/// </summary>
		/// <param name="sender"></param>
		/// <returns></returns>
		public static StringBuilder EnCodeHtml(string sender)
		{
			StringBuilder sb=new StringBuilder(sender);
			sb.Replace("'","&apos;");
			sb.Replace("&","&amp;");
			sb.Replace("\r\n","<br>");
			return sb;
		}
		/// <summary>
		/// ����HTML��&apos;תΪ�������š�\r\nתΪ�س���
		/// </summary>
		/// <param name="sender"></param>
		/// <returns></returns>
		public static StringBuilder DeCodeHtml(string sender)
		{
			StringBuilder sb=new StringBuilder(sender);
			sb.Replace("&apos;","'");
			sb.Replace("&amp;","&");
			sb.Replace("<br>","\r\n");
			return sb;
		}
		#endregion

		#region ����ϴ��ļ�������
		/// <summary>
		/// ����ϴ��ļ�������
		/// </summary>
		/// <param name="files"></param>
		/// <param name="savePath"></param>
		/// <returns></returns>
		public static ArrayList UpLoadImages(HttpFileCollection files, string savePath)
		{
			ArrayList arrList=new ArrayList();
			string attachImg;

			for(int iFile = 0; iFile < files.Count; iFile++)
			{
				HttpPostedFile postedFile = files[iFile];
				attachImg = System.IO.Path.GetFileName(postedFile.FileName);
				attachImg=GetEtcOfFileName(attachImg);
				if (attachImg != string.Empty && attachImg!=null)
				{
					postedFile.SaveAs(savePath + attachImg);
					arrList.Add(attachImg);
				}
			}
			return arrList;
		}

		//picName��������չ��
		public static string UpLoadImages(HtmlInputFile file, string savePath, string picName)
		{
			string attachImg;
			savePath = HttpContext.Current.Server.MapPath(savePath);

			HttpPostedFile postedFile = file.PostedFile;
			attachImg = System.IO.Path.GetFileName(postedFile.FileName);
			if(picName==null || picName==string.Empty)
				attachImg=GetEtcOfFileName(attachImg);
			else
				attachImg=picName + attachImg.Substring(attachImg.LastIndexOf("."));
			if (attachImg != string.Empty && attachImg!=null)
			{
				postedFile.SaveAs(savePath + attachImg);
			}
			return attachImg;
		}
		#endregion

		#region ����ʱ��õ��ļ�����
		/// <summary>
		/// ����ʱ��õ��ļ�����
		/// </summary>
		/// <returns></returns>
		public static string GetFileNameByTime()
		{
			string sFileName;
			sFileName=DateTime.Now.Year.ToString()+DateTime.Now.Month.ToString()+DateTime.Now.Day.ToString()+
				DateTime.Now.Hour.ToString()+DateTime.Now.Minute.ToString()+DateTime.Now.Second.ToString()+
				DateTime.Now.Millisecond.ToString();
			return sFileName;
		}
		private static string GetEtcOfFileName(string sFileName)
		{
			string sEtc;//�ļ�����չ����
			if(sFileName.LastIndexOf(".")>0)
				sEtc=sFileName.Substring(sFileName.LastIndexOf("."));
			else
				sEtc="";
			sEtc=GetFileNameByTime() + sEtc;
			return sEtc;
		}
		#endregion

		#region ʱ���ʽת���� �磺2004-10-1
		public static string ConvertShortDateString(object date)
		{
			string sDate;
			try
			{
				sDate=Convert.ToDateTime(date).ToShortDateString();
			}
			catch
			{
				sDate=date.ToString();
			}
			return sDate;
		}

		public static double ConvertToDouble(object Sender)
		{
			try
			{
				string str = Sender.ToString();
				str = str.Replace("��", ".");
				str = str.Replace("��", "");
				return Convert.ToDouble(str);
			}
			catch
			{
				return 0;
			}
		}

		public static DateTime ConvertToDateTime(object Sender)
		{
			try
			{
				string str = Sender.ToString();
				str = str.Replace("��", "-");
				str = str.Replace(".", "-");
				str = str.Replace("��", "-");
				return Convert.ToDateTime(str);
			}
			catch
			{
        return DateTime.Parse("1900-1-1");
			}
		}

		public static int ConvertToInt(object Sender)
		{
			try
			{
				return Convert.ToInt32(Sender);
			}
			catch
			{
				return 0;
			}
		}

    public static bool ConvertToBoolean(object Sender)
    {
      try
      {
        return Convert.ToBoolean(Sender);
      }
      catch
      {
        return false;
      }
    }

		public static string ConvertToString(object Sender)
		{
			try
			{
				return Convert.ToString(Sender);
			}
			catch
			{
				return string.Empty;
			}
		}
		#endregion

		#region ��������
		public static long GetRandom(long smallNum, long bigNum)
		{
			Random rnd=new Random();
			long lngNum=(long)(rnd.NextDouble() * (bigNum - smallNum)) + smallNum;
			return lngNum;
		}
		public static long GetRandom(long smallNum, long bigNum,int seed )
		{
			Random rnd=new Random(seed);
			long lngNum=(long)(rnd.NextDouble() * (bigNum - smallNum)) + smallNum;
			return lngNum;
		}
		#endregion

		#region �Ƴ�Html��ǩ
		public static string RemoveHtmlLabel(object oContent)
		{
			string content = oContent.ToString();
			int startIndex=0;
			int preLabel_Position				=0;									//<��ʼλ��
			int sufLabel_Position				=0; 								//>��ʼλ��
			string preLabel							="<";
			string sufLabel							=">";

			int temp=100;
			while(true && temp-->0)
			{
				if(content.Equals(null))break;
				preLabel_Position			=	content.IndexOf(preLabel,startIndex);
				if(preLabel_Position<0)break;
				sufLabel_Position			=	content.IndexOf(sufLabel,preLabel_Position);
				if(preLabel_Position>=0 && sufLabel_Position<0)
				{
					content=content.Remove(preLabel_Position,	content.Length-preLabel_Position);
					break;
				}
				content=content.Remove(preLabel_Position,sufLabel_Position-preLabel_Position + 1);
			}
			content=content.Replace("  ","");
			content=content.Replace("��","");
			content=content.Replace("&nbsp;","");
			content=content.Replace("&NBSP;","");
			return content;
		}
		#endregion

		#region ����ָ�����ַ�����
		public static string Left(string content, int length)
		{
			if(content==null || content==string.Empty)return content;
			int strLen=content.Length;
			if(strLen>length)
				return content.Substring(0,length) + "...";
			else
				return content;
		}
		#endregion

		#region ����ֻ������
		public static string GetDate(string dateTime)
		{
			string getDate;
			try
			{
				getDate=Convert.ToDateTime(dateTime).ToShortDateString();
			}
			catch
			{
				getDate=dateTime;
			}
			return getDate;
		}
		#endregion

		#region �ָ��ַ���
		public static string[] SplitString(object oStr, string splitStr)
		{
			string str = ConvertToString(oStr);
			string[] arrStr=null;
			if(str!=null)
				arrStr=str.Split(splitStr.ToCharArray());
			return arrStr;
		}
		public static string[] SplitString(object OriginString)
		{
			return SplitString(OriginString, ",");
		}
		public static string SplitStringGetFirst(object OriginString)
		{
			string[] str = SplitString(OriginString, ",");
			if(str!=null&&str.Length>0)return str[0];
			else return string.Empty;
		}
		#endregion

		#region 2004.10.31 Gzb  �õ�һ�仰��ʵ��ռ�õġ����ġ��ַ��Ŀ���
		public static string GetQiaoJiaoStringByNum(string sContent,int iNum)
		{
			//2004.10.31 Gzb �õ�һ�仰��ʵ��ռ�õġ����ġ��ַ��Ŀ���
			// ���磺�й�2004 -->4�����Ŀ��� (6���֣�
			if(sContent==null || sContent==string.Empty || sContent.Length<iNum)
				return sContent;

			char[] cArray=sContent.ToCharArray();
			int iAlreadyNum=0;
			int iOkLenNum=0;
			foreach (char cH in cArray)
			{
				if(iAlreadyNum < iNum * 2)
				{
					if(cH>128)
					{
						iAlreadyNum+=2;
					}
					else
						iAlreadyNum++;
					iOkLenNum++;
				}
				else
					break;
			}
			sContent=sContent.Substring(0,iOkLenNum)+"...";
			return sContent;
		}
		#endregion

		#region ����������תΪ���Ĵ�д
    public static string NumberToBigRMB(decimal num)
    {
      string str1 = "��Ҽ��������½��ƾ�";            //0-9����Ӧ�ĺ��� 
      string str2 = "��Ǫ��ʰ��Ǫ��ʰ��Ǫ��ʰԪ�Ƿ�"; //����λ����Ӧ�ĺ��� 
      string str3 = "";    //��ԭnumֵ��ȡ����ֵ 
      string str4 = "";    //���ֵ��ַ�����ʽ 
      string str5 = "";  //����Ҵ�д�����ʽ 
      int i;    //ѭ������ 
      int j;    //num��ֵ����100���ַ������� 
      string ch1 = "";    //���ֵĺ������ 
      string ch2 = "";    //����λ�ĺ��ֶ��� 
      int nzero = 0;  //����������������ֵ�Ǽ��� 
      int temp;            //��ԭnumֵ��ȡ����ֵ 

      num = Math.Round(Math.Abs(num), 2);    //��numȡ����ֵ����������ȡ2λС�� 
      str4 = ((long)(num * 100)).ToString();        //��num��100��ת�����ַ�����ʽ 
      j = str4.Length;      //�ҳ����λ 
      if (j > 15) { return "���"; }
      str2 = str2.Substring(15 - j);   //ȡ����Ӧλ����str2��ֵ���磺200.55,jΪ5����str2=��ʰԪ�Ƿ� 

      //ѭ��ȡ��ÿһλ��Ҫת����ֵ 
      for (i = 0; i < j; i++)
      {
        str3 = str4.Substring(i, 1);          //ȡ����ת����ĳһλ��ֵ 
        temp = Convert.ToInt32(str3);      //ת��Ϊ���� 
        if (i != (j - 3) && i != (j - 7) && i != (j - 11) && i != (j - 15))
        {
          //����ȡλ����ΪԪ�����ڡ������ϵ�����ʱ 
          if (str3 == "0")
          {
            ch1 = "";
            ch2 = "";
            nzero = nzero + 1;
          }
          else
          {
            if (str3 != "0" && nzero != 0)
            {
              ch1 = "��" + str1.Substring(temp * 1, 1);
              ch2 = str2.Substring(i, 1);
              nzero = 0;
            }
            else
            {
              ch1 = str1.Substring(temp * 1, 1);
              ch2 = str2.Substring(i, 1);
              nzero = 0;
            }
          }
        }
        else
        {
          //��λ�����ڣ��ڣ���Ԫλ�ȹؼ�λ 
          if (str3 != "0" && nzero != 0)
          {
            ch1 = "��" + str1.Substring(temp * 1, 1);
            ch2 = str2.Substring(i, 1);
            nzero = 0;
          }
          else
          {
            if (str3 != "0" && nzero == 0)
            {
              ch1 = str1.Substring(temp * 1, 1);
              ch2 = str2.Substring(i, 1);
              nzero = 0;
            }
            else
            {
              if (str3 == "0" && nzero >= 3)
              {
                ch1 = "";
                ch2 = "";
                nzero = nzero + 1;
              }
              else
              {
                if (j >= 11)
                {
                  ch1 = "";
                  nzero = nzero + 1;
                }
                else
                {
                  ch1 = "";
                  ch2 = str2.Substring(i, 1);
                  nzero = nzero + 1;
                }
              }
            }
          }
        }
        if (i == (j - 11) || i == (j - 3))
        {
          //�����λ����λ��Ԫλ�������д�� 
          ch2 = str2.Substring(i, 1);
        }
        str5 = str5 + ch1 + ch2;

        if (i == j - 1 && str3 == "0")
        {
          //���һλ���֣�Ϊ0ʱ�����ϡ����� 
          str5 = str5 + '��';
        }
      }
      if (num == 0)
      {
        str5 = "��Ԫ��";
      }
      return str5;
    }

    /// <summary> 
    /// һ�����أ����ַ�����ת���������ڵ���CmycurD(decimal num) 
    /// </summary> 
    /// <param name="num">�û�����Ľ��ַ�����ʽδת��decimal</param> 
    /// <returns></returns> 
    public static string NumberToBigRMB(object numstr)
    {
      try
      {
        decimal num = Convert.ToDecimal(numstr);
        return NumberToBigRMB(num);
      }
      catch
      {
        return numstr.ToString();
      }
    }
    #endregion
		
		#region ���ĳ��ĳ�µ�������
		public static int GetDays(int Year, int Month)
		{
			int reVal;
			if(Month<12)
			{
				DateTime dt = new DateTime(Year, Month + 1, 1);
				dt = dt.AddDays(-1);
				reVal = dt.Day;
			}
			else
			{
				reVal = 31;
			}
			return reVal;
		}
		#endregion 

	}
}
