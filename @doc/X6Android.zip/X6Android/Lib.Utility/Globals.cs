#region
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Drawing;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Xml;
using System.Web.Caching;
using System.Text.RegularExpressions;
using System.Text;
using System.Web.Security;
using System.Diagnostics;
using System.Globalization;
using System.Net.Mail;
using System.Data;

using Lib.Utility;

using MExcel = Microsoft.Office.Interop.Excel;
#endregion

namespace Lib.Utility
{

    public class Globals
    {
        #region
        public static int Menu_Id
        {
            get
            {
                return Func.ConvertToInt(GetRequest("Menu_Id"));
            }
        }

        public static int PMenu_Id
        {
            get
            {
                return Func.ConvertToInt(GetRequest("PMenu_Id"));
            }
        }

        public static int Module_Id
        {
            get
            {
                return Func.ConvertToInt(GetRequest("Module_Id"));
            }
        }

        public static int Params_Id
        {
            get
            {
                return Func.ConvertToInt(GetRequest("Params_Id"));
            }
        }

        public static int Type_Id
        {
            get
            {
                return Func.ConvertToInt(GetRequest("Type_Id"));
            }
        }

        public static string Params_Type
        {
            get
            {
                return GetRequest("Params_Type");
            }
        }

        public static string Key_Id
        {
            get { return GetRequest("Key_Id"); }
        }

        /// <summary>
        /// ��Ҫ�Զ�������ֶ�
        /// </summary>
        public static string CodeRegular
        {
            get { return GetRequest("CodeRegular"); }
        }

        /// <summary>
        /// �����������ϸ��֮��������
        /// </summary>
        public static string ForeignKey
        {
            get
            {
                string k = GetRequest("ForeignKey");
                if (string.IsNullOrEmpty(k)) k = Globals.Key_Id;
                return k;
            }
        }

        /// <summary>
        /// ��ϸ����
        /// </summary>
        public static string DetailKeyId
        {
            get
            {
                return GetRequest("DetailKeyId");
            }
        }

        /// <summary>
        /// �������
        /// </summary>
        public static string ModeType
        {
            get
            {
                string m = GetRequest("ModeType");
                m = string.IsNullOrEmpty(m) ? GetRequest("Mode_Type") : m;
                m = string.IsNullOrEmpty(m) ? Globals.Operation : m;
                return m;
            }
        }

        /// <summary>
        /// ����ͳ��
        /// </summary>
        public static bool IsGroup
        {
            get
            {
                string m = GetRequest("IsGroup");
                return m == "true";
            }
        }

        public static string PrimaryValue
        {
            get
            {
                return GetRequest("PrimaryValue");
            }
        }

        public static string ParentKeyId
        {
            get
            {
                return GetRequest("ParentKeyId");
            }
        }

        public static string Dept_Id
        {
            get
            {
                return GetRequest("Dept_Id");
            }
        }

        /// <summary>
        /// ҳ�沼����
        /// </summary>
        public static string EditorLayout
        {
            get
            {
                return GetRequest("EditorLayout");
            }
        }

        /// <summary>
        /// ��ʵ������ͼ����
        /// </summary>
        public static string TableName
        {
            get
            {
                string tableName = GetRequest("TableName");
                if (string.IsNullOrEmpty(tableName)) tableName = Globals.Table_Name;

                return tableName;
            }
        }
        /// <summary>
        /// ��ʵ������
        /// </summary>
        public static string TableView
        {
            get
            {
                string tableView = GetRequest("TableView");
                if (string.IsNullOrEmpty(tableView)) tableView = Globals.TableName;
                if (string.IsNullOrEmpty(tableView)) tableView = Globals.Table_NameEx;
                if (string.IsNullOrEmpty(tableView)) tableView = Globals.Table_Name;

                return tableView;
            }
        }

        /// <summary>
        /// ��ϸ ��ʵ������ͼ����
        /// </summary>
        public static string DetailName
        {
            get { return GetRequest("DetailName"); }
        }

        public static string DetailView
        {
            get
            {
                string nameEx = GetRequest("DetailView");
                if (string.IsNullOrEmpty(nameEx)) return Globals.DetailName;
                else return nameEx;
            }
        }

        /// <summary>
        /// ��ʵ������ͼ����
        /// </summary>
        public static string Table_Name
        {
            get
            {
                string tableName = GetRequest("Table_Name");
                return tableName;
            }
        }

        public static string Table_View
        {
            get
            {
                return GetRequest("Table_View");
            }
        }

        /// <summary>
        /// ���������ͼ����
        /// </summary>
        public static string Table_NameEx
        {
            get
            {
                string nameEx = GetRequest("Table_NameEx");
                if (string.IsNullOrEmpty(nameEx)) return Table_Name;
                else return nameEx;
            }
        }

        public static string Action
        {
            get
            {
                return GetRequest("Action");
            }
        }

        /// <summary>
        /// �ļ�������
        /// </summary>
        public static string FolderName
        {
            get
            {
                string F = Globals.GetRequest("FolderName");
                if (string.IsNullOrEmpty(F)) F = Globals.GetRequest("F");

                return F;
            }
        }

        /// <summary>
        /// �༭����
        /// </summary>
        public static string EditType
        {
            get
            {
                string E = Globals.GetRequest("EditType");
                if (string.IsNullOrEmpty(E)) E = Globals.GetRequest("E");

                return E;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public static string Operation
        {
            get
            {
                string op = GetRequest("op");
                if (op == null) op = GetRequest("Operation");
                return op;
            }
        }

        /// <summary>
        /// �߼��ؼ���
        /// </summary>
        public static string Biz
        {
            get
            {
                string Biz = GetRequest("Biz");
                if (Biz == null) Biz = Globals.Operation;
                return Biz;
            }
        }

        /// <summary>
        /// ���ҳ��
        /// </summary>
        public static string FrameWork
        {
            get
            {
                string w = GetRequest("FrameWork");
                if (w == null) w = GetRequest("W");
                return w;
            }
        }

        /// <summary>
        /// ��������������
        /// </summary>
        public static string DropDownTableView
        {
            get
            {
                string T = Globals.GetRequest("DropDownTableView");
                if (string.IsNullOrEmpty(T)) T = Globals.GetRequest("T");

                return T;
            }
        }

        public static string LinkColumn
        {
            get
            {
                return GetRequest("LinkColumn");
            }
        }

        public static string Where
        {
            get
            {
                return GetRequest("Where");
            }
        }
        #endregion

        #region ���� ·��
        public static string ConnMasterString
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["ConnMasterString"];
            }
        }

        private static string _Theme;
        public static string Theme
        {
            get
            {
                return "Default";
            }
            set
            {
                _Theme = value;
            }
        }

        static public string IPAddress
        {
            get
            {
                HttpContext context = HttpContext.Current;
                return GetUserIpAddress(context);
            }
        }

        static public string AppPath
        {
            get
            {
                string s = HttpContext.Current.Request.ApplicationPath;
                if (!s.EndsWith("/")) s += "/";
                return s;
            }

        }

        static public String SkinPath
        {
            get
            {
                string theme = AppPath + "App_Themes/" + Theme + "/";
                return theme;
            }
        }

        static public string Language
        {
            get
            {
                return GetRequest("Language");
            }
        }

        public static string SiteAbsPath
        {
            get
            {
                return HttpContext.Current.Server.MapPath(AppPath);
            }
        }

        public static string Login_Name
        {
            get
            {
                return HttpContext.Current.User.Identity.Name;
            }
        }

        public static string URLPath
        {
            get
            {
                string url = HttpContext.Current.Request.RawUrl;
                return Func.SplitString(url, "?")[0];
            }
        }

        public static string URL
        {
            get
            {
                string url = "http://" + HttpContext.Current.Request.Url.Host;
                int port = HttpContext.Current.Request.Url.Port;
                if (port != 80) url += ":" + port;

                return url;
            }
        }

        /// <summary>
        /// ͼƬ����
        /// </summary>
        public static string ImagesDomain
        {
            get
            {
                string url = System.Configuration.ConfigurationManager.AppSettings["ImagesDomain"];
                return url;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public static string RootDomain
        {
            get
            {
                string url = System.Configuration.ConfigurationManager.AppSettings["RootDomain"];
                return url;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public static string MainDomain
        {
            get
            {
                string url = System.Configuration.ConfigurationManager.AppSettings["MainDomain"];
                return url;
            }
        }

        public static string GetAppSettings(string keyString)
        {
            return System.Configuration.ConfigurationManager.AppSettings[keyString];
        }

        public static string Roles_Id
        {
            get
            {
                string cookieName = FormsAuthentication.FormsCookieName;
                HttpCookie authCookie = HttpContext.Current.Request.Cookies[cookieName];
                FormsAuthenticationTicket authTicket = null;
                try
                {
                    authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                    if (string.IsNullOrEmpty(authTicket.UserData)) return "0";
                    return authTicket.UserData;
                }
                catch
                {
                    return "0";
                }
            }
        }

        public static string Roles_Name
        {
            get
            {
                string cookieName = FormsAuthentication.FormsCookieName;
                HttpCookie authCookie = HttpContext.Current.Request.Cookies[cookieName];
                FormsAuthenticationTicket authTicket = null;
                try
                {
                    authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                    return authTicket.UserData;
                }
                catch
                {
                    return string.Empty;
                }
            }
        }

        //��¼�û�ID
        public static string UserName
        {
            get
            {
                return (HttpContext.Current == null) ? "System" : HttpContext.Current.User.Identity.Name;
            }
        }

        //��¼�û�ID
        public static string User_Id
        {
            get
            {
                return Globals.GetRequest("User_Id");
            }
        }

        /// <summary>
        /// ���ؿ��ٲ�ѯ��
        /// </summary>
        public static bool IsLoadQuickBar
        {
            get
            {
                string Q = Globals.GetRequest("IsLoadQuickBar");
                if (string.IsNullOrEmpty(Q)) Q = Globals.GetRequest("Q");

                return Q == "true";
            }
        }

        /// <summary>
        /// �Ƿ����ȫ������
        /// </summary>
        public static bool IsLoadAllDropdown
        {
            get
            {
                string D = Globals.GetRequest("IsLoadAllDropdown");
                if (string.IsNullOrEmpty(D)) D = Globals.GetRequest("D");

                return D == "true";
            }
        }

        /// <summary>
        /// �Ƿ��Զ���༭ҳ��
        /// </summary>
        public static bool IsCustomEdit
        {
            get
            {
                return Globals.GetRequest("IsCustomEdit") == "true";
            }
        }

        #region վ����Ը�·��
        public static string PathWebRoot
        {
            get
            {
                return HttpContext.Current.Server.MapPath("/") + "\\";
            }
        }
        #endregion

        #region վ������ϴ��ļ�·��
        public static string PathUpLoadAbs
        {
            get
            {
                return HttpContext.Current.Server.MapPath("/") + "\\UpLoad\\";
            }
        }
        #endregion
        #endregion

        #region GetUserIpAddress
        public static string GetUserIpAddress(HttpContext context)
        {
            string result = String.Empty;
            if (context == null) return result;

            result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (null == result || result == String.Empty)
                result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];

            if (result == null || result == "")
                result = HttpContext.Current.Request.UserHostAddress;

            return result;
        }
        #endregion

        #region ת��
        public static String HtmlDecode(String FormattedMessageSubject)
        {
            // strip the HTML - i.e., turn < into &lt;, > into &gt;
            return HttpContext.Current.Server.HtmlDecode(FormattedMessageSubject);
        }

        public static String HtmlEncode(String FormattedMessageSubject)
        {
            // strip the HTML - i.e., turn < into &lt;, > into &gt;
            return HttpContext.Current.Server.HtmlEncode(FormattedMessageSubject);
        }

        public static String UrlDecode(object oUrl)
        {
            if (oUrl == null) return string.Empty;

            string url = oUrl.ToString();
            // strip the HTML - i.e., turn < into &lt;, > into &gt;
            return HttpContext.Current.Server.UrlDecode(url);
        }

        public static String UrlEncode(object oUrl)
        {
            if (oUrl == null) return string.Empty;
            string url = oUrl.ToString();
            // strip the HTML - i.e., turn < into &lt;, > into &gt;
            return HttpContext.Current.Server.UrlEncode(url);
        }

        public static string ChangeBRtoEnter(object oStr)
        {
            string sStr = oStr.ToString();
            sStr = sStr.Replace("<br>", "\r\n");
            sStr = sStr.Replace("<BR>", "\r\n");
            sStr = sStr.Replace("&apos;", "'");
            sStr = sStr.Replace("&#59;", ";");
            return sStr;
        }

        public static string ChangeEntertoBR(object oStr)
        {
            string sStr = oStr.ToString();
            sStr = sStr.Replace("\r\n", "<BR>");
            sStr = sStr.Replace("'", "&apos;");
            sStr = sStr.Replace(";", "&#59;");
            return sStr;
        }
        #endregion

        #region ���Ĭ��ֵ
        public static Hashtable DefaultValue
        {
            get
            {
                Hashtable ht = new Hashtable();
                string defaultValue = Globals.GetRequest("defaultValue");
                string[] defaultValueArr = Func.SplitString(defaultValue);
                for (int i = 0; i < defaultValueArr.Length; i++)
                {
                    string[] arr = Func.SplitString(defaultValueArr[i], "=");
                    ht.Add(arr[0], arr[1]);
                }

                return ht;
            }
        }

        /// <summary>
        /// ��URL������Ĭ��ֵ
        /// </summary>
        /// <returns></returns>
        public static string SetMasterDefaultValueFromURL()
        {
            string html = string.Empty;
            string defaultValue = Globals.GetRequest("MasterDefaultValue");
            if (string.IsNullOrEmpty(defaultValue)) return string.Empty;

            string[] defaultValueArr = Func.SplitString(defaultValue);
            for (int i = 0; i < defaultValueArr.Length; i++)
            {
                string[] arr = Func.SplitString(defaultValueArr[i], "=");
                string keyName = arr[0];
                string keyValue = arr[1];

                html += "m_datasetMaster.getField('" + keyName + "').setDefaultValue('" + keyValue + "');\r\n";
            }


            return html;
        }

        /// <summary>
        /// ��URL������Ĭ��ֵ 
        /// </summary>
        /// <returns></returns>
        public static string GetDefaultValueFromURL(string pKeyName)
        {
            string defaultValue = Globals.GetRequest("MasterDefaultValue");
            if (string.IsNullOrEmpty(defaultValue)) return string.Empty;

            string[] defaultValueArr = Func.SplitString(defaultValue);
            for (int i = 0; i < defaultValueArr.Length; i++)
            {
                string[] arr = Func.SplitString(defaultValueArr[i], "=");
                string keyName = arr[0];
                string keyValue = arr[1];

                if (keyName == pKeyName) return keyValue;
            }
            return string.Empty;
        }
        #endregion

        #region ��������·��
        public static string PathAdminAbs
        {
            get
            {
                return PathWebRoot + "Admin\\";
            }
        }
        #endregion

        #region GetRequest
        public static string GetRequest(int Index)
        {
            string htmlValue = GetRequestsNameValue().GetValues(Index).GetValue(0).ToString();
            htmlValue = UrlDecode(htmlValue);
            return htmlValue;
        }

        public static string GetRequest(string Key)
        {
            string htmlValue = string.Empty;
            try
            {
                htmlValue = System.Web.HttpContext.Current.Request[Key];
                //				htmlValue = UrlDecode(htmlValue);
            }
            catch
            {
            }
            return htmlValue;
        }

        private static NameValueCollection GetRequestsNameValue()
        {
            string url = HttpContext.Current.Request.Url.AbsoluteUri;
            int startIndex = url.IndexOf("?");
            NameValueCollection values = new NameValueCollection();

            if (startIndex <= 0)
                return null;

            string[] nameValues = url.Substring(startIndex + 1).Split('&');

            foreach (string s in nameValues)
            {
                string[] pair = s.Split('=');

                string name = pair[0];
                string value = string.Empty;

                if (pair.Length > 1)
                    value = pair[1];

                values.Add(name, value);
            }
            return values;
        }
        #endregion

        #region GetRequests
        public static string GetRequests
        {
            get
            {
                string url = HttpContext.Current.Request.Url.AbsoluteUri;
                int startIndex = url.IndexOf("?");

                if (startIndex <= 0)
                    return string.Empty;

                string[] nameValues = url.Split('?');
                if (nameValues.Length < 2) return string.Empty;
                string RequestValue = nameValues[1];
                return RequestValue;
            }
        }
        #endregion

        #region RequestRemoveLast
        public static string RequestRemoveLast()
        {
            string Requests = Globals.GetRequests;
            Requests = Requests.Substring(0, Requests.LastIndexOf('&'));
            return Requests;
        }
        /// <summary>
        /// �Ƴ���ѯ������ֵ
        /// </summary>
        /// <param name="keys">����ؼ���</param>
        /// <returns></returns>
        public static string RequestRemoveKeys(string keys)
        {
            string Requests = string.Empty;
            string[] RequestsArr = Func.SplitString(Globals.GetRequests, "&");
            string[] keyArr = Func.SplitString(keys);
            foreach (string r in RequestsArr)
            {
                bool isExist = false;
                foreach (string k in keyArr)
                {
                    if (r.StartsWith(k)) isExist = true;
                }
                if (isExist) continue;

                if (!string.IsNullOrEmpty(Requests)) Requests += "&";
                Requests += r;
            }
            return Requests;
        }
        #endregion

        #region ConvertToRMB
        public static string ConvertToRMB(object obj)
        {
            NumberFormatInfo nfi = new CultureInfo("zh-CN", false).NumberFormat;
            double dec = Func.ConvertToDouble(obj);
            return dec.ToString("C", nfi);
        }
        #endregion

        #region MD5
        public static string MD5(object oCry)
        {
            return FormsAuthentication.HashPasswordForStoringInConfigFile(oCry.ToString(), "MD5");
        }
        #endregion

        #region Write
        public static void Write(string Html)
        {
            HttpContext.Current.Response.Write(Html);
        }
        #endregion

        #region cookies����
        public static void WriteCookies(string Key_Id, object Value)
        {
            WriteCookies(Key_Id, Value, 1);
        }

        public static void WriteCookies(string Key_Id, object Value, int Days)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[Key_Id];
            string currValue = string.Empty;
            if (cookie != null)
            {
                #region
                currValue = cookie.Value;
                string[] valueArr = Func.SplitString(currValue);
                bool isExist = false;
                for (int i = 0; i < valueArr.Length; i++)
                {
                    if (valueArr[i] == Value.ToString())
                    {
                        isExist = true;
                        break;
                    }
                }
                if (!isExist)
                {
                    currValue += "," + Value;
                }
                #endregion
            }
            else
            {
                currValue = Value.ToString();
            }
            HttpContext.Current.Response.Cookies[Key_Id].Expires = DateTime.Now.AddDays(Days);
            HttpContext.Current.Response.Cookies[Key_Id].Value = currValue;
        }

        public static string GetCookies(string Key_Id)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[Key_Id];
            if (cookie == null) return string.Empty;
            else return cookie.Value;
        }

        public static void ClearCookies(string Key_Id)
        {
            HttpContext.Current.Response.Cookies[Key_Id].Value = string.Empty;
            HttpContext.Current.Response.Cookies[Key_Id].Expires = DateTime.Now.AddYears(-50);
        }
        #endregion

        #region �������
        public static string GetDateTimeToString()
        {
            return DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() +
                DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() +
                DateTime.Now.Millisecond.ToString();
        }
        public static string GetWeek()
        {
            return GetWeek(DateTime.Now);
        }

        public static string GetWeek(object oDate)
        {
            string sWeek = string.Empty;
            DateTime dTime = Func.ConvertToDateTime(oDate);
            switch (dTime.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    sWeek = "����һ";
                    break;
                case DayOfWeek.Tuesday:
                    sWeek = "���ڶ�";
                    break;
                case DayOfWeek.Wednesday:
                    sWeek = "������";
                    break;
                case DayOfWeek.Thursday:
                    sWeek = "������";
                    break;
                case DayOfWeek.Friday:
                    sWeek = "������";
                    break;
                case DayOfWeek.Saturday:
                    sWeek = "������";
                    break;
                case DayOfWeek.Sunday:
                    sWeek = "������";
                    break;
            }
            return sWeek;
        }
        #endregion

        #region ������ʱ�䣬����������
        public static string GetCurrTimeOtherDate(object oDate)
        {
            string sDate = oDate.ToString();
            if (sDate == null || sDate == string.Empty) return string.Empty;
            DateTime dt = Func.ConvertToDateTime(oDate);
            if (dt.ToShortDateString() == DateTime.Now.ToShortDateString())
            {
                return dt.ToString("hh:mm:ss");
            }
            else
            {
                return dt.ToString("yyyy-MM-dd");
            }
        }
        #endregion

        #region ���������
        public static string GetSpanSec(object oFromTime, object oToTime)
        {
            DateTime FromTime = Func.ConvertToDateTime(oFromTime);
            DateTime ToTime = Func.ConvertToDateTime(oToTime);
            TimeSpan span = ToTime - FromTime;
            return span.TotalSeconds.ToString();
        }
        #endregion

        #region ��ò�ѯ���Where����
        public static NameValueCollection GetWhere()
        {
            NameValueCollection NameValues = new NameValueCollection();
            string Where = UrlDecode(HttpContext.Current.Request["Where"]);
            if (Where == null || Where == string.Empty) return null;
            //��ö����ѯ���
            string[] WhereArr = Func.SplitString(Where, ",");
            if (WhereArr == null) return null;
            for (int i = 0; i < WhereArr.Length; i++)
            {
                //��ò�ѯ����ֵ
                string[] WhereArr_Arr = Func.SplitString(WhereArr[i], ":");
                NameValues.Add(WhereArr_Arr[0], WhereArr_Arr[1]);
            }
            return NameValues;
        }

        public static string GetWhere(string Key)
        {
            NameValueCollection NameValues = GetWhere();
            try
            {
                return NameValues[Key];
            }
            catch
            {
                return string.Empty;
            }
        }
        #endregion

        #region ���� ���Language.xml�е�����ֵ
        public static string GetConfig(string Key, string TableName)
        {
            Hashtable ht = GetConfig(Globals.TableName);
            string reVal;
            try
            {
                reVal = ht[Key].ToString();
            }
            catch
            {
                reVal = string.Empty;
            }
            return reVal;
        }

        public static Hashtable GetConfig(string TableName)
        {
            string Path = HttpContext.Current.Server.MapPath("/XML/Config.xml");
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(Path);
            XmlNode TableNode = xmlDoc.SelectSingleNode("/Root/Table[@Name=\"" + TableName + "\"]");
            Hashtable ht = new Hashtable();
            foreach (XmlNode node in TableNode.ChildNodes)
            {
                if (node.NodeType == XmlNodeType.Element)
                {
                    string Value = node.Attributes[0].Value;
                    string InnerText = node.InnerText;
                    InnerText = InnerText.Replace("SkinPath", Globals.SkinPath).Replace("\r\n", "").Replace("\t", "");
                    ht.Add(Value, InnerText);
                }
            }
            return ht;
        }
        #endregion

        #region ��������
        public static void ExportData(string FileType, string FileName, Repeater rpt, Repeater rpt2)        //��Repeater����
        {
            HttpContext.Current.Response.Charset = "GB2312";
            HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("GB2312");

            HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" +
              HttpUtility.UrlEncode(FileName, Encoding.UTF8).ToString());
            HttpContext.Current.Response.ContentType = FileType;
            StringWriter tw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(tw);
            rpt.RenderControl(hw);
            tw.WriteLine("<br>");
            rpt2.RenderControl(hw);
            HttpContext.Current.Response.Write(tw.ToString());
            HttpContext.Current.Response.End();
        }

        public static void ExportData(string FileType, string FileName, Repeater rpt)        //��Repeater����
        {
            HttpContext.Current.Response.Charset = "gb2312";
            HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("GB2312");

            HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" +
              HttpUtility.UrlEncode(FileName, Encoding.UTF8).ToString());
            HttpContext.Current.Response.AppendHeader("Content-Type", "Application/vnd.ms-word; charset=gb2312");
            StringWriter tw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(tw);
            rpt.RenderControl(hw);
            HttpContext.Current.Response.Write(tw.ToString());
            HttpContext.Current.Response.End();
        }

        public static void ExportDataByDataGrid(string FileName, DataGrid dg)        //��DataGrid����
        {
            HttpContext.Current.Response.Charset = "GB2312";
            HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("GB2312");

            HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" +
              HttpUtility.UrlEncode(FileName, Encoding.UTF8).ToString());
            HttpContext.Current.Response.AppendHeader("Content-Type", "Application/vnd.ms-excel; charset=GB2312");
            StringWriter tw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(tw);
            dg.RenderControl(hw);
            HttpContext.Current.Response.Write(tw.ToString());
            HttpContext.Current.Response.End();
        }

        public static void ExportData(string fileName, GridView gv)
        {
            System.Web.HttpResponse httpResponse = HttpContext.Current.Response;
            httpResponse.AppendHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8));
            httpResponse.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
            httpResponse.ContentType = "Application/vnd.ms-excel";
            System.IO.StringWriter tw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            gv.RenderControl(hw);
            string filePath = HttpContext.Current.Server.MapPath("/Download/") + fileName;
            System.IO.StreamWriter sw = new StreamWriter(filePath, false, Encoding.Unicode);
            sw.Write(tw.ToString());
            sw.Close();

            DownFile(httpResponse, fileName, filePath);
            httpResponse.End();
        }

        public static void ExportData(string fileName, DataGrid dg)
        {
            fileName = fileName.Replace('\\', '-').Replace('/', '-').Replace(':', '-').Replace('*', '-').Replace('?', '-').Replace('"', '-').Replace('<', '-').Replace('>', '-').Replace('|', '-');
            //fileName = System.Text.RegularExpressions.Regex.Replace(fileName, "^[\\,/,:,*,?,\",<,>,|]+$", "-", RegexOptions.IgnoreCase);
            System.Web.HttpResponse httpResponse = HttpContext.Current.Response;
            httpResponse.AppendHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8));
            httpResponse.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
            httpResponse.ContentType = "Application/vnd.ms-excel";
            //����������������������䣬�ɱ���Excel/Word���ݳ�����������
            //HttpContext.Current.Response.Write("<meta http-equiv=Content-Type content=text/html;charset=UTF-8>"); 
            System.IO.StringWriter tw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            dg.RenderControl(hw);
            string filePath = HttpContext.Current.Server.MapPath("/Download/") + fileName;
            System.IO.StreamWriter sw = new StreamWriter(filePath, false, Encoding.Unicode);
            sw.Write(tw.ToString());
            sw.Close();

            DownFile(httpResponse, fileName, filePath);
            httpResponse.End();
        }

        /// <summary>
        /// �����ļ�
        /// </summary>
        /// <param name="Response">��Page������HttpResponse����</param>
        /// <param name="fileName">�ļ���</param>
        /// <param name="fullPath">·��</param>
        /// <returns></returns>
        public static bool DownFile(System.Web.HttpResponse Response, string fileName, string fullPath)
        {
            try
            {
                Response.ContentType = "application/octet-stream";

                Response.AppendHeader("Content-Disposition", "attachment;filename=" +
                HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8) + ";charset=GB2312");
                System.IO.FileStream fs = System.IO.File.OpenRead(fullPath);
                long fLen = fs.Length;
                int size = 102400;//ÿ100Kͬʱ�������� 
                byte[] readData = new byte[size];//ָ���������Ĵ�С 
                if (size > fLen) size = Convert.ToInt32(fLen);
                long fPos = 0;
                bool isEnd = false;
                while (!isEnd)
                {
                    if ((fPos + size) >= fLen)
                    {
                        size = Convert.ToInt32(fLen - fPos);
                        readData = new byte[size];
                        isEnd = true;
                    }
                    fs.Read(readData, 0, size);//����һ��ѹ���� 
                    Response.BinaryWrite(readData);
                    fPos += size;
                }
                fs.Close();
                System.IO.File.Delete(fullPath);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region ����Excel����
        public static void ExportExcelData(string FileName, Repeater rpt)        //��Repeater����
        {
            HttpContext.Current.Response.Charset = "GB2312";
            HttpContext.Current.Response.ContentEncoding = Encoding.GetEncoding("GB2312");

            HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" +
              HttpUtility.UrlEncode(FileName, Encoding.UTF8).ToString());
            HttpContext.Current.Response.AppendHeader("Content-Type", "Application/vnd.ms-excel; charset=GB2312");
            StringWriter tw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(tw);
            rpt.RenderControl(hw);
            HttpContext.Current.Response.Write(tw.ToString());
            HttpContext.Current.Response.End();
        }

        public static void ExportExcelData(Repeater rpt)        //��Repeater����
        {
            ExportExcelData("", rpt);
        }
        #endregion

        #region ����Excel���� ���� Excel Com���
        public static void ExportExcelByCom(DataTable dt, string tableName, Page page)
        {
            int rowIndex = 1;
            int colIndex = 0;
            GC.Collect();
            MExcel.Application excel;
            int tempRow = rowIndex;
            int tempCol = colIndex;

            MExcel._Workbook xBk;
            MExcel._Worksheet xSt;
            excel = new MExcel.ApplicationClass();

            xBk = excel.Workbooks.Add(true);

            xSt = (MExcel._Worksheet)xBk.ActiveSheet;

            //excel.Visible = true;
            // 
            //ȡ�ñ��� 
            // 
            foreach (DataColumn col in dt.Columns)
            {
                colIndex++;
                string cn = col.ColumnName;
                string[] cns = cn.Split('-');
                excel.Cells[rowIndex, colIndex] = col.ColumnName.Trim();
                /* �����ע��
                if (cns.Length != 2)
                {
                    excel.Cells[rowIndex, colIndex] = col.ColumnName.Trim();
                }
                else
                {
                    excel.Cells[rowIndex - 1, colIndex] = "'" + cns[0].Trim();
                    excel.Cells[rowIndex, colIndex] = cns[1].Trim();
                }*/
            }
            foreach (DataRow row in dt.Rows)
            {
                rowIndex++;
                colIndex = 0;
                foreach (DataColumn col in dt.Columns)
                {
                    colIndex++;
                    if (col.DataType == System.Type.GetType("System.DateTime"))
                    {
                        excel.Cells[rowIndex, colIndex] = Convert.ToString(row[col.ColumnName]) == "" ? "" : (Convert.ToDateTime(row[col.ColumnName].ToString())).ToString("yyyy-MM-dd");
                    }
                    else if (col.DataType == System.Type.GetType("System.String"))
                    {
                        excel.Cells[rowIndex, colIndex] = "'" + row[col.ColumnName].ToString();

                    }
                    else
                    {
                        excel.Cells[rowIndex, colIndex] = row[col.ColumnName].ToString();

                    }
                }
            }

            excel.Visible = false;
            xBk.SaveCopyAs(page.Server.MapPath(".") + "\\" + tableName + ".xls");

            xBk.Close(false, null, null);
            excel.Quit();
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xBk);
            }
            catch
            { }
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);
            }
            catch
            { }
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xSt);
            }
            catch
            { }
            xBk = null;
            excel = null;
            xSt = null;
            GC.Collect();
            string path = page.Server.MapPath("" + tableName + ".xls");
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            page.Response.Clear();
            page.Response.Charset = "GB2312";
            page.Response.ContentEncoding = System.Text.Encoding.UTF8;
            // ����ͷ��Ϣ��Ϊ"�ļ�����/����Ϊ"�Ի���ָ��Ĭ���ļ��� 
            page.Response.AddHeader("Content-Disposition", "attachment; filename=" + page.Server.UrlEncode(file.Name));
            // ����ͷ��Ϣ��ָ���ļ���С����������ܹ���ʾ���ؽ��� 
            page.Response.AddHeader("Content-Length", file.Length.ToString());
            // ָ�����ص���һ�����ܱ��ͻ��˶�ȡ���������뱻���� 
            page.Response.ContentType = "application/ms-excel";
            // ���ļ������͵��ͻ��� 
            page.Response.WriteFile(file.FullName);
            // ֹͣҳ���ִ��    
            page.Response.End();

        }
        #endregion

        #region �˳�ϵͳ
        public static void LogOut(string logoutUrl)
        {
            HttpCookie c = HttpContext.Current.Response.Cookies[FormsAuthentication.FormsCookieName];
            c.Value = null;
            c.Domain = Globals.RootDomain;
            c.Expires = new System.DateTime(1980, 10, 12);

            FormsAuthentication.SignOut();
            HttpContext.Current.Response.Redirect(logoutUrl);
            HttpContext.Current.Response.End();
        }

        public static void LogOut()
        {
            LogOut(Globals.AppPath);
        }
        #endregion

        #region �ض���
        public static void Redirect(string URL)
        {
            HttpContext.Current.Response.Redirect(URL);
            HttpContext.Current.Response.End();
        }
        #endregion

        #region ��ȡ�ļ�����
        public static string ReadTextFromFile(string FileName)
        {
            StreamReader reader = File.OpenText(Globals.SiteAbsPath + FileName);
            string text = reader.ReadToEnd();
            reader.Close();
            return text;
        }
        #endregion

        #region ����ַ������ָ���ĳ���
        public static string GetLeftString(object oStr, int Length)
        {
            string sStr = Func.ConvertToString(oStr);
            if (sStr.Length <= Length)
            {
                return sStr;
            }
            else
            {
                return sStr.Substring(0, Length);
            }
        }
        #endregion

        #region ��ҳ��
        public static string SplitPage(object oStr)
        {
            string sStr = Func.ConvertToString(oStr);
            string script = string.Empty;
            string splitStr = "<div style=\"PAGE-BREAK-AFTER: always\"><span style=\"DISPLAY: none\">&nbsp;</span></div>";
            int splitStrLength = splitStr.Length;
            if (sStr.IndexOf(splitStr) > 0)
            {
                #region
                int startPos = 0;
                int tabId = 1;
                sStr = "<div id='page" + tabId + "_Content' style='display:inline;'>" + sStr;	//���ӿ�ʼ��ǩ

                //�Ų�
                script = "<script language=javascript>var oPages = new tabStrip(document.all(\"tabs\"));";
                script += "oPages.add('page" + tabId + "', '[" + tabId + "]', 'page" + tabId + "_Content',true);\r\n";

                while (sStr.IndexOf(splitStr, startPos) > 0)
                {
                    tabId++;
                    startPos = sStr.IndexOf(splitStr, startPos);
                    string pageFlag = "</div><div id='page" + tabId + "_Content' style='display:none;'>";
                    sStr = sStr.Insert(startPos + splitStrLength, pageFlag);
                    script += "oPages.add('page" + tabId + "', '[" + tabId + "]', 'page" + tabId + "_Content',false);\r\n";
                    startPos++;
                }
                sStr += "</div><br><br><div id='tabs'></div>";

                script += "</script>";
                #endregion
            }
            return sStr + script;
        }
        #endregion

        #region �����Ŀ��ɫȨ��
        public static string GetAuth(string AuthValue, string Action)
        {
            string[] AuthArr = Func.SplitString(AuthValue);
            if (AuthArr == null || AuthArr.Length <= 0) return "false";
            for (int i = 0; i < AuthArr.Length; i++)
            {
                string[] AuthItemArr = Func.SplitString(AuthArr[i], "=");
                try
                {
                    if (Action == AuthItemArr[0] && AuthItemArr[1] == "1") return "true";
                }
                catch { }
            }
            return "false";
        }

        public static bool GetIsAuth(string AuthValue, string Action)
        {
            string[] AuthArr = Func.SplitString(AuthValue);
            if (AuthArr == null || AuthArr.Length <= 0) return false;
            for (int i = 0; i < AuthArr.Length; i++)
            {
                string[] AuthItemArr = Func.SplitString(AuthArr[i], "=");
                try
                {
                    if (Action == AuthItemArr[0] && AuthItemArr[1] == "1") return true;
                }
                catch { }
            }
            return false;
        }

        /// <summary>
        /// ��������Ա
        /// </summary>
        /// <returns></returns>
        public static bool IsSuperAdminRoles()
        {
            string RolesAdmin = ((int)Const.Roles.Admin).ToString();
            string[] Roles_IdArr = Func.SplitString(Globals.Roles_Id);
            foreach (string Roles_Id in Roles_IdArr)
            {
                if (Roles_Id == RolesAdmin) return true;
            }

            return false;
        }
        #endregion

        #region ����������ת������������
        public static string NumToCN(object oNum)
        {
            string sNum = Func.ConvertToString(oNum);
            sNum = sNum.Replace("1", "һ");
            sNum = sNum.Replace("2", "��");
            sNum = sNum.Replace("3", "��");
            sNum = sNum.Replace("4", "��");
            sNum = sNum.Replace("6", "��");
            sNum = sNum.Replace("7", "��");
            sNum = sNum.Replace("8", "��");
            sNum = sNum.Replace("9", "��");
            sNum = sNum.Replace("0", "��");
            return sNum;
        }
        #endregion

        #region �����ʼ�
        /// <summary>
        /// �����ʼ�
        /// </summary>
        /// <param name="FromMail">���ͷ��ʼ���ַ </param>
        /// <param name="ToMail">���շ��ʼ���ַ������ʼ���ַ�ö��ŷָ� </param>
        /// <param name="Subject">�ʼ����� </param>
        /// <param name="Body">�ʼ����ݣ�֧��HTML��ʽ </param>
        /// <param name="SmtpServer">�ʼ���������ַ </param>
        /// <param name="ServerMail">�����ʼ���ַ </param>
        /// <param name="Pwd">�����ʼ����� </param>
        /// <returns></returns>
        public static string SendMail(string FromMail, string ToMail, string Subject,
          string Body, string SmtpServer, string ServerMail, string Pwd)
        {
            MailMessage mailMsg = new MailMessage(FromMail, ToMail);
            mailMsg.Subject = Subject;
            mailMsg.Body = Body;
            mailMsg.IsBodyHtml = true;

            try
            {
                SmtpClient smtp = new SmtpClient(SmtpServer);
                System.Net.NetworkCredential nc = new System.Net.NetworkCredential(ServerMail, Pwd);
                smtp.Credentials = nc;
                smtp.Send(mailMsg);

                return "ok";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        #endregion

        #region ��ʼ������
        public static void InitDropDownList(DropDownList ddList, object oValue)
        {
            InitDropDownList(ddList, oValue, false);
        }

        public static void InitDropDownList(DropDownList ddList, object oValue, bool IsText)
        {
            for (int i = 0; i < ddList.Items.Count; i++)
            {
                string v = ddList.Items[i].Value;
                if (IsText) v = ddList.Items[i].Text;
                if (v == oValue.ToString())
                {
                    ddList.Items[i].Selected = true;
                }
                else
                {
                    ddList.Items[i].Selected = false;
                }
            }
        }
        #endregion

        #region ��������ͼFullFileName ���·����SmallFullFileName СͼƬ���·��
        public static bool CreateThumbnailImage(string FileName, string SmallFileName, int sWidth, int sHeight)
        {
            string FullFileName = HttpContext.Current.Server.MapPath(FileName);
            string SmallFullFileName = HttpContext.Current.Server.MapPath(SmallFileName);
            //			try
            //			{
            System.Drawing.Image image = System.Drawing.Image.FromFile(FullFileName);
            int width = image.Width;
            int height = image.Height;
            int newwidth, newheight;
            if (width > height)
            {
                newwidth = sWidth;
                newheight = Func.ConvertToInt(1.0 * image.Height / image.Width * newwidth);
            }
            else
            {
                newheight = sHeight;
                newwidth = Func.ConvertToInt(1.0 * image.Width / image.Height * newheight);
            }

            System.Drawing.Image.GetThumbnailImageAbort myCallback = new
                System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);

            System.Drawing.Image aNewImage = image.GetThumbnailImage(newwidth, newheight, myCallback, new System.IntPtr());
            aNewImage.Save(SmallFullFileName);
            image.Dispose();
            return true;
            //			}
            //			catch
            //			{
            //				return false;
            //			}
        }

        public static bool ThumbnailCallback()
        {
            return false;
        }
        #endregion

        #region ���һ���µ����һ��
        public static int GetLastDayInMonth(object oYear, object oMonth)
        {
            string d = oYear.ToString() + "-" + oMonth.ToString();
            int day = 31;

            for (int i = 26; i < 32; i++)
            {
                string localDay = d + "-" + i.ToString();
                try
                {
                    Convert.ToDateTime(localDay);
                    day = i;
                }
                catch
                {
                    day = i - 1;
                }
            }
            return day;
        }
        #endregion

        #region RedirectUrl
        public static void RedirectUrl(string Url)
        {
            HttpContext.Current.Response.Redirect(Globals.AppPath + Url);
            HttpContext.Current.Response.End();
        }
        #endregion

        #region ��ò�ѯ����
        public static string GetSearch(Panel plSearch)
        {
            string Where = string.Empty;    //��ѯ����

            //�������
            foreach (Control ctrl in plSearch.Controls)
            {
                if (ctrl == null || ctrl.ID == null) continue;

                string ID = ctrl.ID;
                if (ID.StartsWith("txt"))        //�ı���
                {
                    #region
                    TextBox box = (TextBox)ctrl;
                    string content = box.Text;
                    if (string.IsNullOrEmpty(content))
                    {
                        continue;
                    }

                    if (!string.IsNullOrEmpty(Where)) Where += " And ";
                    string SearchKey = box.Attributes["SearchKey"];
                    if (!string.IsNullOrEmpty(SearchKey)) //��Ӧ����ֶ�
                    {
                        string[] SearchKeyArr = Func.SplitString(SearchKey);
                        for (int i = 0; i < SearchKeyArr.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(Where) && i > 0) Where += " Or ";
                            Where += SearchKeyArr[i] + " Like '%" + box.Text + "%' ";
                        }
                    }
                    else
                    {
                        ID = ID.Replace("txt", "").Replace("__", ".");
                        if (ID.EndsWith("_From"))
                        {
                            ID = ID.Replace("_From", "");
                            Where += ID + " >= '" + box.Text + "' ";
                        }
                        else if (ID.EndsWith("_To"))
                        {
                            ID = ID.Replace("_To", "");
                            Where += ID + " <= '" + box.Text + "' ";
                        }
                        else
                        {
                            Where += ID + " Like '%" + box.Text + "%' ";
                        }
                    }
                    #endregion
                }
                else if (ID.StartsWith("ddlx"))        //������ ��ȷ��ѯ
                {
                    DropDownList list = (DropDownList)ctrl;
                    string content = list.SelectedValue;
                    if (string.IsNullOrEmpty(content) || content == "-1")
                    {
                        continue;
                    }

                    if (!string.IsNullOrEmpty(Where)) Where += " And ";
                    Where += ID.Replace("ddlx", "").Replace("__", ".") + " = '" + list.SelectedValue + "' ";
                }
                else if (ID.StartsWith("ddl"))        //������ ģ����ѯ
                {
                    DropDownList list = (DropDownList)ctrl;
                    string content = list.SelectedValue;
                    if (string.IsNullOrEmpty(content) || content == "-1")
                    {
                        continue;
                    }

                    if (!string.IsNullOrEmpty(Where)) Where += " And ";
                    ID = ID.Replace("ddl", "").Replace("__", ".");
                    if (ID.EndsWith("_From"))
                    {
                        ID = ID.Replace("_From", "");
                        Where += ID + " >= '" + list.SelectedValue + "' ";
                    }
                    else if (ID.EndsWith("_To"))
                    {
                        ID = ID.Replace("_To", "");
                        Where += ID + " <= '" + list.SelectedValue + "' ";
                    }
                    else
                    {
                        Where += ID + " Like '%" + list.SelectedValue + "%' ";
                    }
                }

            }

            return Where;
        }
        #endregion

        #region ����ڼ���
        public static int GetWeekOfCurrDate(DateTime dt, out DateTime _BeginDayOfWeek, out DateTime _EndDayOfWeek)
        {
            int Week = 1;
            int nYear = dt.Year;
            System.DateTime FirstDayInYear = new DateTime(nYear, 1, 1);
            System.DateTime LastDayInYear = new DateTime(nYear, 12, 31);
            int DaysOfYear = Convert.ToInt32(LastDayInYear.DayOfYear);
            int WeekNow = Convert.ToInt32(FirstDayInYear.DayOfWeek) - 1;
            if (WeekNow < 0) WeekNow = 6;
            int DayAdd = 6 - WeekNow;
            System.DateTime BeginDayOfWeek = new DateTime(nYear, 1, 1);
            System.DateTime EndDayOfWeek = BeginDayOfWeek.AddDays(DayAdd);
            Week = 2;
            for (int i = DayAdd + 1; i <= DaysOfYear; i++)
            {
                BeginDayOfWeek = FirstDayInYear.AddDays(i);
                if (i + 6 > DaysOfYear)
                {
                    EndDayOfWeek = BeginDayOfWeek.AddDays(DaysOfYear - i - 1);
                }
                else
                {
                    EndDayOfWeek = BeginDayOfWeek.AddDays(6);
                }

                if (dt.Month == EndDayOfWeek.Month && dt.Day <= EndDayOfWeek.Day)
                {
                    break;
                }
                Week++;
                i = i + 6;
            }
            _BeginDayOfWeek = BeginDayOfWeek;
            _EndDayOfWeek = EndDayOfWeek;
            return Week;
        }
        #endregion

        #region �쳣������־����
        public static void WriteErrorLog(string ErrorContent)
        {
            string logPath = HttpContext.Current.Server.MapPath("/XML/log.htm");
            WriteErrorLog(ErrorContent, logPath);
        }
        /// <summary>
        /// �쳣������־���� 
        /// </summary>
        /// <param name="ErrorContent">��������</param>
        /// <param name="logPath">/XML/log.htm</param>
        public static void WriteErrorLog(string ErrorContent, string logPath)
        {
            XMLUtil xml = new XMLUtil(logPath, XMLUtil.enumXmlPathType.AbsolutePath);
            XmlNode root = xml.GetXmlRoot();
            XmlNode node = xml.AddChildNode(root, "div");
            string msg = "<b>ʱ�䣺</b>" + DateTime.Now.ToString() + "�� <b>����Ա��</b>" + Globals.UserName;
            xml.AddChildNode(node, "div", msg);  //ʱ�䡢�û�

            msg = "<b>��Դ��</b>" + (HttpContext.Current == null ? "System" : HttpContext.Current.Request.Url.ToString());
            xml.AddChildNode(node, "div", msg);  //������ַ
            string err = "<b>Message��</b>" + ErrorContent + "<br/>\r\n";
            xml.AddChildNode(node, "div", err);

            xml.AddChildNode(node, "hr", string.Empty);
        }

        public static void ExceptionLog(Exception ex, string OtherContent)
        {
            XMLUtil xml = new XMLUtil("/XML/log.htm");
            XmlNode root = xml.GetXmlRoot();
            XmlNode node = xml.AddChildNode(root, "div");
            string msg = "<b>ʱ�䣺</b>" + DateTime.Now.ToString() + "�� <b>����Ա��</b>" + Globals.UserName;
            xml.AddChildNode(node, "div", msg);  //ʱ�䡢�û�

            msg = "<b>������Դҳ�棺</b>" + HttpContext.Current.Request.Url.ToString();
            xml.AddChildNode(node, "div", msg);  //������ַ
            string err = "<b>Error Message��</b>" + ex.Message + "<br/>\r\n<b>Stack Trace��</b>\r\n" + ex.StackTrace.Replace("&", "&amp;")
                  .Replace("at ", "<br/>at ").Replace("��", "<br/>��");
            err += "\r\n" + OtherContent;
            xml.AddChildNode(node, "div", err);

            xml.AddChildNode(node, "hr", string.Empty);
        }

        public static void ExceptionLog(Exception ex)
        {
            string err = string.Empty;

            foreach (string v in ex.Data.Values)
            {
                err += v + "\r\n";
            }
            ExceptionLog(ex, err);
        }
        #endregion

        #region XML�����ַ�ת��
        public static string XmlEscape(string xml)
        {
            return xml.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
        }
        public static string DataSetXmlEscape(object xml)
        {
            return xml.ToString().Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("%", "%25").Replace(",", "%2C");
        }
        #endregion
    }
}