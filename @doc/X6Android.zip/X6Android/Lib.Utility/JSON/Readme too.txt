I changed the source code to make it more suitable for the openflashchart.
add SkipNull  property,allow the serializer  not to  serialize the null value;
delete some unused methods and interface ,attribute.

the original source code can get from 
http://jsonfx.net/BuildTools/#JSON

visit my blog
http://xiao-yifang.blogspot.com


xiao yifang
