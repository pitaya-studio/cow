using System;
using System.Web;
using System.Web.UI.HtmlControls ;
using System.Web.UI;

namespace Lib.Utility
{
	/// <summary>
	/// Java Script����
	/// </summary>
	public class JScriptUtil
	{
		/// <summary>
		/// ����JavaScriptС����Ȼ����ת��ָ��ҳ��
		/// </summary>
		/// <param name="message">������ʾ��Ϣ</param>
		/// <param name="toURL">��תҳ��</param>
		public static void AlertAndRedirect(string message,string toURL)
		{
			string js = "<script language=javascript>alert('{0}');window.location.replace('{1}')</script>";
			HttpContext.Current.Response.Write(string.Format(js,message ,toURL));
		}

		/// <summary>
		/// ��ͻ��˷��ͺ���KendoPostBack(eventTarget, eventArgument)
		/// �������˿ɽ���__EVENTTARGET,__EVENTARGUMENT��ֵ
		/// </summary>
		/// <param name="page">BasePage һ��Ϊthis</param>
		public static void JscriptSender(System.Web.UI.Page page)
		{

			page.RegisterHiddenField("__EVENTTARGET","");
			page.RegisterHiddenField("__EVENTARGUMENT","");
			string s = @"		
			<script language=Javascript>
			function KendoPostBack(eventTarget, eventArgument) 
			{
				var theform = document.forms[0];
				theform.__EVENTTARGET.value = eventTarget;
				theform.__EVENTARGUMENT.value = eventArgument;
				theform.submit();
			}
			</script>";			
			page.RegisterStartupScript("sds",s);
		}

		/// <summary>
		/// ����JavaScriptС����
		/// </summary>
		/// <param name="js">������ʾ��Ϣ</param>
		public static void Alert(string message)
		{
			message = StringUtil.DeleteUnVisibleChar(message);
			string js=@"<Script language='JavaScript'>
                    alert('{0}');
                  </Script>";
			HttpContext.Current.Response.Write(string.Format(js,message));
		}

		/// <summary>
		/// ����JavaScriptС����
		/// </summary>
		/// <param name="js">������ʾ��Ϣ</param>
		public static void AlertAndCloseWindow(string message)
		{
			message = StringUtil.DeleteUnVisibleChar(message);
			string js=@"<Script language='JavaScript'>
                    alert('{0}'); window.close();
                  </Script>";
			HttpContext.Current.Response.Write(string.Format(js,message));
		}

		/// <summary>
		/// ����JavaScriptС����
		/// </summary>
		/// <param name="js">������ʾ��Ϣ</param>
		public static void AlertAndCloseWindowAndRefreshParentWindow(string message)
		{
			//message = StringUtil.DeleteUnVisibleChar(message);
			//string js=@"<Script language='JavaScript'>
			// alert('{0}'); window.close();
                 
			//HttpContext.Current.Response.Write(string.Format(js,message));
			
			System.Text.StringBuilder scriptString = new System.Text.StringBuilder(); 
			scriptString.Append("<script language = javascript>"); 
			scriptString.Append(" alert('"+message+"');");

			scriptString.Append("window.opener.refresh();"); 

			scriptString.Append( " window.focus();" ); 
			scriptString.Append( " window.opener=null;" ); 
			scriptString.Append( " window.close(); " ); 

			scriptString.Append("</"+"script>"); 
			HttpContext.Current.Response.Write(scriptString.ToString()); 

		}

		/// <summary>
		/// ����JavaScriptС����
		/// </summary>
		/// <param name="message">������ʾ��Ϣ</param>
		public static void Alert(object message)
		{
			string js=@"<Script language='JavaScript'>
                    alert('{0}');  
                  </Script>";
			HttpContext.Current.Response.Write(string.Format(js,message.ToString()));
		}

		/// <summary>
		/// ����ȷ�ϴ���
		/// </summary>
		/// <param name="message">������Ϣ</param>
		/// <param name="strWinCtrl"></param>
		public static void RtnRltMsgbox(object message,string strWinCtrl)
		{   
			string js = @"<Script language='JavaScript'>
					 strWinCtrl = true;
                     strWinCtrl = if(!confirm('"+ message +"'))return false;</Script>";
			HttpContext.Current.Response.Write(string.Format(js,message.ToString()));
		}

		/// <summary>
		/// ����ȷ�ϴ���
		/// </summary>
		/// <param name="message">������Ϣ</param>
		/// <param name="strWinCtrl"></param>
		public static void RtnRltMsgbox(string message,string strWinCtrl)
		{   
			string js = @"<Script language='JavaScript'>
					 strWinCtrl = true;
                     strWinCtrl = if(!confirm('"+ message +"'))return false;</Script>";
			HttpContext.Current.Response.Write(string.Format(js,message.ToString()));
		}
		
		/// <summary>
		/// �ص���ʷҳ��
		/// </summary>
		/// <param name="value">-1/1</param>
		public static void GoHistory(int value)
		{
			string js=@"<Script language='JavaScript'>
                    history.go({0});  
                  </Script>";
			HttpContext.Current.Response.Write(string.Format(js,value));
		}

		/// <summary>
		/// �رյ�ǰ����
		/// </summary>
		public static void CloseWindow()
		{
			string js=@"<Script language='JavaScript'>
                    window.close();  
                  </Script>";
			HttpContext.Current.Response.Write(js);     
			HttpContext.Current.Response.End();  
		}

		/// <summary>
		/// ˢ�¸�����
		/// </summary>
		public static void RefreshParent()
		{
			string js=@"<Script language='JavaScript'>
                    parent.location.reload();
                  </Script>";
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// ��ʽ��ΪJS�ɽ��͵��ַ���
		/// </summary>
		/// <param name="s"></param>
		/// <returns></returns>
		public static string JSStringFormat(string s)
		{
			return s.Replace("\r","\\r").Replace("\n","\\n").Replace("'","\\'").Replace("\"","\\\"");
		}

		/// <summary>
		/// ˢ�´򿪴���
		/// </summary>
		public static void RefreshOpener()
		{
			string js=@"<Script language='JavaScript'>
                    opener.location.reload();
                  </Script>";
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// �¿�ҳ��ȥ��ie�Ĳ˵�
		/// </summary>
		/// <param name="url"></param>
		public static void OpenWebForm(string url)
		{
			string js=@"<Script language='JavaScript'>
			window.open('"+url+@"','','height=0,width=0,top=0,left=0,location=no,menubar=no,resizable=yes,scrollbars=yes,status=yes,titlebar=no,toolbar=no,directories=no');
			</Script>";      
                
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// �¿�ҳ��ȥ��ie���ϴ�����
		/// </summary>
		/// <param name="url"></param>
		public static void OpenUploadForm(string url,int width,int height)
		{
			string js=@"<Script language='JavaScript'>
			window.open('"+url+@"','','height="+height+@",width="+width+@",top=0,left=0,location=no,menubar=no,resizable=yes,scrollbars=yes,status=yes,titlebar=no,toolbar=no,directories=no');
			</Script>";      
                
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// �¿�ҳ��ȥ��ie�Ĳ˵���������ҳ�泬ʱʱ��
		/// </summary>
		/// <param name="url"></param>
		public static void OpenWebFormAndSetInterval(string url,int tntervalTime)
		{
			string js=@"<Script language='JavaScript'>
			newopen=window.open('"+url+@"',0,0);
			setInterval('wen()',10); </Script>";      
                
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// �ر���ҳ���ͬʱ�ø�ҳ���Զ�ˢ��һ��
		/// </summary>
		/// <param name="url"></param>
		public static void CloseWebFormAndRefreshParentWindow()
		{
			string js=@"<script> 
		function wen()
		{ 
			if(newopen.closed)
			{ 
				window.location.reload(); 
			} 
		} 
		</script>";
			HttpContext.Current.Response.Write(js);    
		}
		/// <summary>
		/// �¿�ҳ��
		/// </summary>
		/// <param name="url"></param>
		public static void OpenWebForm(string url,int width,int heigth)
		{
			string js=@"<Script language='JavaScript'>
			//window.open('"+url+@"');
			window.open('"+url+@"','','height='"+width+@"',width='"+heigth+@"',top=0,left=0,location=no,menubar=no,resizable=yes,scrollbars=yes,status=yes,titlebar=no,toolbar=no,directories=no');
			</Script>";      
                
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// �¿�ҳ��
		/// </summary>
		/// <param name="url"></param>
		/// <param name="name"></param>
		/// <param name="future"></param>
		public static void OpenWebForm(string url,string name,string future)
		{
			string js=@"<Script language='JavaScript'>
                     window.open('"+url+@"','"+name+@"','"+future+@"')
                  </Script>";
			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>
		/// �¿�ҳ��ȥ��ie�Ĳ˵�
		/// </summary>
		/// <param name="url"></param>
		/// <param name="formName"></param>
		public static void OpenWebForm(string url,string formName)
		{
			string js=@"<Script language='JavaScript'>
			//window.open('"+url+@"','"+formName+@"');
			window.open('"+url+@"','"+formName+@"','height=0,width=0,top=0,left=0,location=no,menubar=no,resizable=yes,scrollbars=yes,status=yes,titlebar=no,toolbar=no,directories=no');
			</Script>";

			HttpContext.Current.Response.Write(js);     
		}

		/// <summary>		
		/// ��������:��WEB����	
		/// </summary>
		/// <param name="url">WEB����</param>
		/// <param name="isFullScreen">�Ƿ�ȫ��Ļ</param>
		public static void OpenWebForm(string url,bool isFullScreen)
		{			
			string js=@"<Script language='JavaScript'>";
			if(isFullScreen)
			{
				js+="var iWidth = 0;";
				js+="var iHeight = 0;";
				js+="iWidth=window.screen.availWidth-10;";
				js+="iHeight=window.screen.availHeight-50;";
				js+="var szFeatures ='width=' + iWidth + ',height=' + iHeight + ',top=0,left=0,location=no,menubar=no,resizable=yes,scrollbars=yes,status=yes,titlebar=no,toolbar=no,directories=no';";
				js+="window.open('"+url+@"','',szFeatures);";
			}
			else
			{
				js+="window.open('"+url+@"','','height=0,width=0,top=0,left=0,location=no,menubar=no,resizable=yes,scrollbars=yes,status=yes,titlebar=no,toolbar=no,directories=no');";
			}
			js+="</Script>";
			HttpContext.Current.Response.Write(js);     
		}
		/// <summary>
		/// ת��Url�ƶ���ҳ��
		/// </summary>
		/// <param name="url"></param>
		public static void JavaScriptLocationHref(string url)
		{
			string js=@"<Script language='JavaScript'>
                    window.location.replace('{0}');
                  </Script>";
			js=string.Format(js,url);
			HttpContext.Current.Response.Write(js);  
		}

		/// <summary>
		/// ָ���Ŀ��ҳ��ת��
		/// </summary>
		/// <param name="FrameName"></param>
		/// <param name="url"></param>
		public static void JavaScriptFrameHref(string FrameName,string url)
		{
			string js=@"<Script language='JavaScript'>
					
                    @obj.location.replace(""{0}"");
                  </Script>";
			js = js.Replace("@obj",FrameName );
			js=string.Format(js,url);
			HttpContext.Current.Response.Write(js);  
		}

		/// <summary>
		///����ҳ��
		/// </summary>
		public static void JavaScriptResetPage(string strRows)
		{
			string js=@"<Script language='JavaScript'>
                    window.parent.CenterFrame.rows='"+strRows+"';</Script>";
			HttpContext.Current.Response.Write(js); 
		}

		/// <summary>
		/// ��������:�ͻ��˷�������Cookie
		/// </summary>
		/// <param name="strName">Cookie��</param>
		/// <param name="strValue">Cookieֵ</param>
		public static void JavaScriptSetCookie(string strName,string strValue)
		{
			string js=@"<script language=Javascript>
			var the_cookie = '"+strName+"="+strValue+@"'
			var dateexpire = 'Tuesday, 01-Dec-2020 12:00:00 GMT';
			//document.cookie = the_cookie;//д��Cookie<BR>} <BR>
			document.cookie = the_cookie + '; expires='+dateexpire;			
			</script>";
			HttpContext.Current.Response.Write(js); 
		}

		/// <summary>		
		/// ��������:���ظ�����	
		/// </summary>
		/// <param name="parentWindowUrl">������</param>		
		public static void GotoParentWindow(string parentWindowUrl)
		{			
			string js=@"<Script language='JavaScript'>
                    this.parent.location.replace('"+parentWindowUrl+"');</Script>";
			HttpContext.Current.Response.Write(js); 			
		}

		/// <summary>		
		/// ��������:�滻������	
		/// </summary>
		/// <param name="parentWindowUrl">������</param>
		/// <param name="caption">������ʾ</param>
		/// <param name="future">������������</param>
		public static void ReplaceParentWindow(string parentWindowUrl,string caption,string future)
		{	
			string js="";
			if(future!=null&&future.Trim()!="")
			{
				js=@"<script language=javascript>this.parent.location.replace('"+parentWindowUrl+"','"+caption+"','"+future+"');</script>";
			}
			else
			{
				js=@"<script language=javascript>var iWidth = 0 ;var iHeight = 0 ;iWidth=window.screen.availWidth-10;iHeight=window.screen.availHeight-50;
							var szFeatures = 'dialogWidth:'+iWidth+';dialogHeight:'+iHeight+';dialogLeft:0px;dialogTop:0px;center:yes;help=no;resizable:on;status:on;scroll=yes';this.parent.location.replace('"+parentWindowUrl+"','"+caption+"',szFeatures);</script>";
			}

			HttpContext.Current.Response.Write(js);
		}
		
		
		/// <summary>		
		/// ��������:�滻��ǰ����Ĵ򿪴���	
		/// </summary>
		/// <param name="openerWindowUrl">��ǰ����Ĵ򿪴���</param>		
		public static void ReplaceOpenerWindow(string openerWindowUrl)
		{			
			string js=@"<Script language='JavaScript'>
                    window.opener.location.replace('"+openerWindowUrl+"');</Script>";
			HttpContext.Current.Response.Write(js); 			
		}

		/// <summary>			
		/// ��������:�滻��ǰ����Ĵ򿪴��ڵĸ�����	
		/// </summary>
		/// <param name="openerWindowUrl">��ǰ����Ĵ򿪴��ڵĸ�����</param>		
		public static void ReplaceOpenerParentFrame(string frameName,string frameWindowUrl)
		{			
			string js=@"<Script language='JavaScript'>
                    window.opener.parent." + frameName + ".location.replace('"+frameWindowUrl+"');</Script>";
			HttpContext.Current.Response.Write(js); 			
		}

		/// <summary>			
		/// ��������:�滻��ǰ����Ĵ򿪴��ڵĸ�����	
		/// </summary>
		/// <param name="openerWindowUrl">��ǰ����Ĵ򿪴��ڵĸ�����</param>		
		public static void ReplaceOpenerParentWindow(string openerParentWindowUrl)
		{			
			string js=@"<Script language='JavaScript'>
                    window.opener.parent.location.replace('"+openerParentWindowUrl+"');</Script>";
			HttpContext.Current.Response.Write(js); 			
		}

		/// <summary>		
		/// ��������:�رմ���	
		/// </summary>
		public static void CloseParentWindow()
		{			
			string js=@"<Script language='JavaScript'>
                    window.parent.close();  
                  </Script>";
			HttpContext.Current.Response.Write(js);
		}
		
		public static void CloseOpenerWindow()
		{			
			string js=@"<Script language='JavaScript'>
                    window.opener.close();  
                  </Script>";
			HttpContext.Current.Response.Write(js);
		}		

		/// <summary>
		/// ��������:���ش�ģʽ���ڵĽű�	
		/// </summary>
		/// <param name="webFormUrl"></param>
		/// <returns></returns>
		public static string ShowModalDialogJavascript(string webFormUrl)
		{
			string js=@"<script language=javascript>
							var iWidth = 0 ;
							var iHeight = 0 ;
							iWidth=window.screen.availWidth-10;
							iHeight=window.screen.availHeight-50;
							var szFeatures = 'dialogWidth:'+iWidth+';dialogHeight:'+iHeight+';dialogLeft:0px;dialogTop:0px;center:yes;help=no;resizable:on;status:on;scroll=yes';
							showModalDialog('"+webFormUrl+"','',szFeatures);</script>";
			return js;
		}

		public static string ShowModalDialogJavascript(string webFormUrl,string features)
		{
			string js=@"<script language=javascript>							
							showModalDialog('"+webFormUrl+"','','"+features+"');</script>";
			return js;
		}

		/// <summary>
		/// ��������:��ģʽ����	
		/// </summary>
		/// <param name="webFormUrl"></param>
		/// <returns></returns>
		public static void ShowModalDialogWindow(string webFormUrl)
		{
			string js = ShowModalDialogJavascript(webFormUrl);
			HttpContext.Current.Response.Write(js);
		}

		/// <summary>
		/// ��������:��ģʽ����
		/// </summary>
		/// <param name="webFormUrl"></param>
		/// <param name="features"></param>
		public static void ShowModalDialogWindow(string webFormUrl,string features)
		{
			string js=ShowModalDialogJavascript(webFormUrl,features);
			HttpContext.Current.Response.Write(js);
		}

		/// <summary>
		/// ��������:��ģʽ����
		/// </summary>
		/// <param name="webFormUrl"></param>
		/// <param name="width"></param>
		/// <param name="height"></param>
		/// <param name="top"></param>
		/// <param name="left"></param>
		public static void ShowModalDialogWindow(string webFormUrl,int width,int height,int top,int left)
		{
			string features = "dialogWidth:"+width.ToString() + "px"
				+";dialogHeight:" + height.ToString() + "px" 
				+";dialogLeft:" + left.ToString() + "px"
				+";dialogTop:" + top.ToString() + "px"
				+";center:yes;help=no;resizable:no;status:no;scroll=no";
			ShowModalDialogWindow(webFormUrl,features);			
		}

		/// <summary>
		/// ��������:
		/// </summary>
		/// <param name="formName"></param>
		/// <param name="elementName"></param>
		/// <param name="elementValue"></param>
		public static void SetHtmlElementValue(string formName,string elementName,string elementValue)
		{			
			string js=@"<Script language='JavaScript'>if(document."+formName+"." + elementName +"!=null){document."+formName+"." + elementName +".value ="+ elementValue +";}</Script>";
			HttpContext.Current.Response.Write(js);
		}		
	}

}