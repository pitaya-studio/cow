#region 
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
#endregion

namespace Lib.Utility
{
	public class Regular
	{
		#region ����
    private string _inputText;
    /// <summary>
    /// Ҫ����ƥ������ַ��� 
    /// </summary>
		public string InputText
		{
			get{
				return _inputText;
			}
			set{
				_inputText = value;
			}
		}

    private string _regexText;
    /// <summary>
    /// Ҫƥ����������ʽģʽ
    /// </summary>
		public string RegexText
		{
			get
			{
				return _regexText;
			}
			set
			{
				_regexText = value;
			}
		}

    private string _replacementText;
    /// <summary>
    /// �滻�ַ���
    /// </summary>
    public string ReplacementText
		{
			get
			{
				return _replacementText;
			}
			set
			{
				_replacementText = value;
			}
		}
		#endregion

		#region Regular
		public Regular()
		{
		}
		#endregion

		#region GetRegexOptions
		public RegexOptions GetRegexOptions()
		{
			RegexOptions regexOptions = RegexOptions.None;
			regexOptions |= RegexOptions.IgnoreCase;
			regexOptions |= RegexOptions.Multiline;
			return regexOptions;
		}
		#endregion

		#region TestRegex
    /// <summary>
    /// ָʾ�������ʽ�������ַ������Ƿ��ҵ�ƥ����
    /// </summary>
    /// <returns>bool</returns>
		public bool TestRegex()
		{
			try
			{
				RegexOptions regexOptions = this.GetRegexOptions();
				Regex testRegex = new Regex(RegexText, regexOptions);

				return testRegex.IsMatch(InputText);
			}
			catch
			{
				return false;
			}
		}
		#endregion

    #region Replace
    public string Replace()
    {
      try
      {
        RegexOptions regexOptions = this.GetRegexOptions();
        Regex replaceRegex = new Regex(RegexText, regexOptions);

        return replaceRegex.Replace(InputText, ReplacementText);
      }
      catch
      {
        return string.Empty;
      }
    }
    #endregion

		#region Split
		public string[] Split()
		{
			try
			{
				RegexOptions regexOptions = this.GetRegexOptions();
				Regex splitRegex = new Regex(RegexText, regexOptions);
				
				return splitRegex.Split(InputText);
			}
			catch
			{
				return null;
			}
		}
		#endregion

		#region Matches
    /// <summary>
    /// �������ַ����������������ʽ������ƥ����������гɹ���ƥ�� 
    /// </summary>
    /// <returns></returns>
    public MatchCollection Matches()
		{
			try
			{
        RegexOptions regexOptions = this.GetRegexOptions();
        Regex matchesRegex = new Regex(RegexText, regexOptions);
        return matchesRegex.Matches(InputText);

//				StringBuilder resultString = new StringBuilder(64);
//				foreach (Match matchMade in matchesFound)
//					resultString.Append(matchMade.Value + Environment.NewLine + nextMatch);
			}
			catch
			{
				return null;
			}
		}
		#endregion

    #region CreateRegex
    public Regex CreateRegex()
		{
			try
			{
        RegexOptions regexOptions = this.GetRegexOptions();
        Regex matchesRegex = new Regex(RegexText, regexOptions);

        return matchesRegex;
			}
			catch
			{
				return null;
			}
		}
		#endregion
	}
}
